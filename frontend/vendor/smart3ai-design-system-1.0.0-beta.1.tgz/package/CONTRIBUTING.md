# Contributing to Smart3AI Design System

`@smart3ai/design-system` contains shared presentation foundations only. It must not contain product business logic, API clients, permissions, routes, models, serializers, payload contracts, authentication, persistence, backend notifications or product-specific workflows.

## When to Share a Component

Create or promote a component when it satisfies all of these conditions:

- At least two Smart3AI products need the same UI pattern, or one product needs it now and another approved product roadmap clearly needs it.
- The component can be expressed with consumer-owned data, copy and handlers.
- The component improves consistency, accessibility or maintenance without embedding product rules.
- The component can be documented, tested and visually evidenced before release.

## When to Keep a Component in a Product

Keep the component local when it depends on product-specific navigation, permissions, API calls, domain copy, data shaping, feature flags, dashboards, charts, uploads, editors, WebSocket state or backend notification behavior.

## Tokens

Token proposals must describe the visual need, expected reuse, affected themes, contrast impact and migration path from any hardcoded value. Prefer reusing an existing semantic token before creating a new global or component token.

## Props and Events

Public props must remain semantic and stable. New props should be optional in alpha and beta releases unless an approved breaking change is documented. Event props must pass consumer-owned events or values and must not trigger product side effects internally.

## Accessibility

Every contribution must preserve WCAG AA expectations for keyboard access, focus visibility, labels, roles, contrast, reduced motion and screen reader behavior. Dialogs, drawers, tooltips, forms and tables require both automated and manual accessibility checks.

## Required Checks

Before requesting review, run:

```bash
npm test
npm run pack:dry-run
```

Run `npm run verify:consumers` when a public export, CSS entrypoint, token, peer dependency or package boundary changes.

## Documentation

Public changes must update the relevant component docs, public API contract, CSS contract, compatibility notes, migration notes and changelog. Experimental APIs must be marked explicitly.

## Visual Evidence

Visual changes require evidence in light mode, dark mode, responsive viewport and keyboard focus states. Static harnesses are acceptable while the package remains private and local.

## Consumer Review

Any change that can affect AdminApps, ISO Smart, ISO Smart MedSupplier or Landing must identify known consumers and include smoke build evidence or a documented reason for deferral.

## Deprecations

Do not remove a public API in the same minor line where it is deprecated. Follow `docs/governance/DEPRECATION_POLICY.md`.

## Naming

React components use `S3` prefix. CSS classes and custom properties use `s3-` and `--s3-*`. Props should describe intent, not implementation detail.

## Imports

Consumers may import React APIs only from `@smart3ai/design-system`. CSS entrypoints are `design-system/styles/platform.css`, future package `@smart3ai/design-system/styles`, and token entrypoint `@smart3ai/design-system/tokens`. Deep imports into `src`, `components`, `layout` or token internals are not public.

## Acceptance Criteria

A contribution is acceptable when it is scoped, documented, accessible, contract-tested, visually evidenced, compatible with known consumers and approved by the required roles.
