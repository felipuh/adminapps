# Changelog

All notable changes to the Smart3AI Component Library are tracked here.

## 1.0.0-alpha.10 - 2026-07-31

- Closed the Beta readiness verification phase without expanding the component catalog or changing product behavior.
- Updated package metadata, public API, runtime compatibility, consumer matrix, release checklist and Beta readiness documentation for `1.0.0-alpha.10`.
- Verified package contract checks, forbidden import validation and token validation through the existing package quality gate.
- Generated and inspected the packed package artifact for allowed package contents, public entrypoints, peer dependencies and absence of local product artifacts.
- Verified isolated consumer smoke builds for AdminApps, ISO Smart, ISO Smart MedSupplier and Landing from the packed tarball in temporary copies, with npm peer-resolution and copied-install dependency warnings documented for Beta follow-up.
- Preserved existing product repositories, local changes, databases, logs, dist folders, Docker, backend, routes, APIs, permissions and deployment state.
- Recorded the Beta decision as GO WITH RESTRICTIONS because artifact consumption is verified through Vite builds, while publication target, repository ownership controls, clean-install dependency hygiene and productive CI wiring remain pending.

## 1.0.0-alpha.9 - 2026-07-31

- Formalized package governance without publishing, tagging, deploying, moving repositories or expanding the component catalog.
- Added repository and distribution ADR for the recommended future platform repository strategy while documenting the current non-Git shared folder state.
- Added ownership, contribution, release, release checklist, deprecation, token, accessibility, security and privacy documentation.
- Added public API, CSS contract, runtime compatibility and consumer compatibility matrices for AdminApps, ISO Smart, ISO Smart MedSupplier and Landing.
- Added Beta readiness roadmap with blockers, acceptable debt and criteria for `1.0.0-beta.1`.
- Strengthened local contract checks with package metadata, exports map, peer dependency, forbidden import and token validation.
- Added opt-in consumer smoke verification script for local package and product builds.
- Added package `files` allowlist and `npm pack --dry-run` script for package contents review.
- Kept npm publication, private registry publication, GitHub release, tags, commits, product migrations, backend changes, Docker, infrastructure, CI production changes and new components out of scope.

## 1.0.0-alpha.8 - 2026-07-31

- Added compositional overlay primitives: `S3Dialog`, dialog subcomponents and `S3Drawer` with portal rendering, focus trap, Escape handling, focus restoration, scroll lock, backdrop behavior, mobile sizing and dark-mode support.
- Refactored `S3ConfirmationDialog` to render through the shared dialog base while preserving its public props, danger tone, loading state, confirm/cancel handlers and consumer-owned copy.
- Added floating interaction primitives: `S3Tooltip` and `S3Popover` for brief help and lightweight interactive content without menu/router/global-shell behavior.
- Added transient feedback primitives: `S3Banner`, `S3Toast`, `S3ToastViewport`, `S3ToastAction`, optional local `S3ToastProvider` placeholder and `S3OperationFeedback`.
- Tokenized overlay layering with `--s3-layer-*` values for sticky, dropdown, popover, drawer, modal and toast layers plus backdrop tokens.
- Added Alpha 8 docs, architecture notes, migration guide, delivery report, static harness and persistent evidence folder.
- Kept backend notifications, WebSockets, polling, persistence, permissions, API calls, modal routing, command palettes, shell navigation, commits, publishing and deploys out of scope.

## 1.0.0-alpha.7 - 2026-07-31

- Added compositional page layout foundations: `S3PageLayout`, `S3PageContent`, `S3PageSection`, `S3ContentSection`, `S3SectionHeader`, `S3ActionBar` and `S3PageActions`.
- Added contextual navigation primitives: `S3Breadcrumbs`, `S3BreadcrumbItem` and `S3BackLink` with consumer-owned routes and labels.
- Added surface and panel primitives plus small spatial helpers: `S3Surface`, `S3Panel`, `S3Stack`, `S3Inline` and `S3Grid`.
- Extended `S3PageHeader` with `description` and `actions` aliases while preserving the existing `subtitle` and `action` API.
- Added Alpha 7 component docs, layout architecture notes, migration guide, delivery report, evidence folder and static layout harness.
- Kept AppShell, sidebar, topbar, auth, permissions, router integration, backend changes, REST contracts, database changes and publication out of scope.

## 1.0.0-alpha.6 - 2026-07-30

- Added compositional data interaction primitives for search, filters, active filter chips, clear filters, results summaries, selection summaries and bulk action bars.
- Strengthened `S3TableHeader` sorting presentation with ascending, descending and unsorted icons plus `sortLabel` support while preserving consumer-owned sort logic.
- Added selected row styling and selection support primitives without introducing product-owned selection state into the Design System.
- Migrated low-risk summaries in ISO Smart and ISO Smart MedSupplier and piloted AdminApps `EnterpriseUI` wrappers for search, filters, active chips and results summaries without changing params, services, permissions or backend contracts.
- Added Alpha 6 harness, architecture, component docs, migration guide, delivery report and AdminApps mapping updates.
- Kept query builders, saved filters, remote autocomplete, React Query, API calls, permissions, exports, universal bulk actions and monolithic data-table behavior out of scope.

## 1.0.0-alpha.5 - 2026-07-30

- Added compositional semantic table primitives: `S3TableContainer`, `S3Table`, `S3TableHead`, `S3TableBody`, `S3TableFooter`, `S3TableRow`, `S3TableHeader`, `S3TableCell` and `S3TableCaption`.
- Added table state and support primitives: `S3TableLoading`, `S3TableEmpty`, `S3TableError`, `S3TableToolbar`, `S3TableActions`, `S3Pagination` and `S3PaginationSummary`.
- Migrated one simple ISO Smart corrective actions table and one simple ISO Smart MedSupplier dashboard account table to shared table presentation primitives without changing data, handlers, permissions, endpoints or translations.
- Promoted AdminApps `EnterpriseUI.DataTable` to a wrapper over `S3TableContainer` and `S3Table` while preserving existing children and consumer imports.
- Added a static design-system visual harness with fictitious data for normal, loading, empty, error and pagination table states.
- Added Alpha 5 architecture, table component, table state, pagination, harness, evidence and migration documentation.
- Kept universal data table configuration, remote query orchestration, backend changes, product API changes, bulk actions and complex table migrations out of scope.

## 1.0.0-alpha.4 - 2026-07-30

- Ran the first Alpha 4 consolidation pass for visual acceptance, browser evidence structure, AdminApps adoption and table discovery documentation.
- Promoted AdminApps `EnterpriseUI` `StatusBadge` and `LoadingState` to low-risk compatibility wrappers over `S3StatusBadge` and `S3LoadingState` while preserving existing consumer imports and business status mapping.
- Migrated one simple ISO Smart MedSupplier workspace delete confirmation from `window.confirm` to `S3ConfirmationDialog` without changing the service call, permissions gate, localized labels, loading flag or reload flow.
- Added Alpha 4 migration, visual acceptance, AdminApps pilot and data-table discovery documentation for the next shared table architecture phase.
- Kept DataTable, AppShell, sidebar, topbar, dashboard framework, charts and complex form/modal migrations out of scope.

## 1.0.0-alpha.3 - 2026-07-30

- Added neutral Enterprise form foundations: `S3FormField`, `S3FieldLabel`, `S3FieldHelp`, `S3FieldError`, `S3Input`, `S3Textarea`, `S3Select`, `S3Checkbox`, `S3Radio` and `S3Switch`.
- Added `S3ConfirmationDialog` for simple consumer-owned confirmation flows with focus handling, Escape support and danger tone.
- Strengthened `S3Button` and `S3IconButton` with ref forwarding and loading `aria-busy` semantics.
- Migrated one clean ISO Smart password reset request form and one clean ISO Smart MedSupplier password reset request form to shared form primitives without changing handlers, field names, submit behavior or translations.
- Extended AdminApps compatibility documentation for form controls and confirmation patterns.
- Added Alpha 3 migration guidance and public API contract checks for the form cohort.

## 1.0.0-alpha.2 - 2026-07-30

- Added the operational `tone` API for `S3StatusBadge` while preserving `status` as a compatibility alias.
- Expanded `S3LoadingState` with `inline`, `section`, `page`, `overlay`, `button` and `skeleton` variants plus configurable `aria-live` and `aria-busy`.
- Expanded `S3Button` with `ghost`, start/end icons, loading behavior and the dedicated `S3IconButton` export for icon-only actions.
- Migrated a small ISO Smart improvement cohort to `S3StatusBadge`, `S3LoadingState` and `S3Button`.
- Migrated a small ISO Smart MedSupplier cohort to shared status badges, loading states and CRUD buttons.
- Added AdminApps EnterpriseUI compatibility mapping without migrating AdminApps runtime components.
- Added alpha.2 consumer guidance and broader public contract tests.

## 1.0.0-alpha.1 - 2026-07-30

- Initialized `@smart3ai/design-system` as a private local ESM package.
- Added public exports for `S3Button`, `S3EmptyState`, `S3InlineAlert`, `S3ErrorState`, `S3LoadingState`, `S3PageHeader` and `S3StatusBadge`.
- Added token-based CSS support for the first shared React component cohort.
- Migrated ISO Smart and ISO Smart MedSupplier CRUD compatibility components to consume the shared public API.
- Added architecture, component and migration documentation.

## Release Policy

- PATCH: compatible fixes to existing components, styles or documentation.
- MINOR: compatible new components, variants or public exports.
- MAJOR: breaking changes to component APIs, exports, tokens or supported consumption strategy.

The package remains private until Smart3AI explicitly authorizes publication.
