# Alpha 7 Layout Foundations

Alpha 7 establishes compositional page foundations for Smart3AI products without creating a universal app shell.

## Decision

The Design System owns page structure primitives: layout width, content flow, contextual breadcrumbs, action bars, surfaces, panels and simple spatial composition.

Products continue to own global navigation, topbar, sidebars, routers, sessions, permissions, API data and business copy.

## Pattern Audit

- AdminApps uses constrained content, enterprise page headers, card/panel wrappers, filters and table sections. It is a wrapper candidate.
- ISO Smart uses `CrudPageHeader`, repeated CRUD sections, Enterprise panels and simple table/form flows. Clean CRUD pages are migration candidates.
- ISO Smart MedSupplier uses the same shared CRUD patterns plus specialized MedSupplier dashboard and workspace layouts. Generic CRUD pages are candidates; MedSupplier workspace/dashboard remain out of scope for Alpha 7.
- Landing is visual reference only. Its dirty `dist` output and visual page styling are not migration targets.

## Out of Scope

No `S3AppShell`, global sidebar, top navigation, route guards, auth, permissions, product switcher, dashboard framework or backend integration was introduced.
