# Alpha 5 Table Architecture

Alpha 5 intentionally avoids a universal `S3DataTable`. Smart3AI products already own different data sources, permission rules, query params, renderers and workflows, so a monolithic data table would centralize business assumptions too early.

## Decision

Provide compositional primitives that preserve HTML table semantics:

- container and table structure;
- header, body, footer, rows, cells and caption;
- table-safe loading, empty and error states;
- toolbar, actions and controlled pagination presentation.

## Boundaries

The design system owns:

- tokenized surface, borders, spacing, hover, focus and responsive overflow;
- semantic tags and base ARIA affordances;
- visual sort affordance and `aria-sort`;
- row-safe state rendering with `tr` and `td`.

Products own:

- API calls, query params and response contracts;
- local or remote pagination semantics;
- filters, search and sorting state;
- row actions, permission checks and disabled reasons;
- business copy and translations;
- renderers and domain-specific formatting.

## Alpha 5 Pilots

- ISO Smart: `ImprovementCorrectiveActionsPage` table presentation migrated to shared primitives.
- ISO Smart MedSupplier: `MedSupplierDashboard` customer account table presentation migrated to shared primitives.
- AdminApps: `EnterpriseUI.DataTable` wrapper now composes `S3TableContainer` and `S3Table`, preserving existing consumers and children.

No backend, API, model, serializer, permission, payload or database behavior is part of this architecture.
