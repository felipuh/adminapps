# ADR-0002: Repository and Distribution Strategy

Date: 2026-07-31

Status: Proposed for Alpha 9

## Context

`@smart3ai/design-system` is currently a shared local package folder at `/home/felipe/proyectos/design-system`. It is not an independent Git repository. Product repositories consume it through Vite aliases that point to `../../design-system/src/index.js` and through direct CSS imports from `design-system/styles/platform.css`.

This gives fast local adoption, but weak traceability. Package history, tags, release approvals, CI, package contents and consumer compatibility checks are not isolated from product repositories.

## Options

### Option A: Independent Repository

Benefits: dedicated history, tags, releases, CODEOWNERS, CI, package publishing and private distribution.

Risks: cross-repository coordination, version skew, release timing and consumer smoke testing complexity.

### Option B: Smart3AI Monorepo

Benefits: atomic changes, workspaces, shared tooling and joint tests.

Risks: costly migration, operational complexity, broad blast radius and tighter coupling between products.

### Option C: Platform Repository

Benefits: keeps the design system with shared tooling, docs, harnesses and future platform packages while avoiding a full product monorepo.

Risks: still requires package publication discipline, repository ownership and consumer compatibility automation.

### Option D: Temporary Shared Folder

Benefits: lowest immediate disruption and matches current alpha adoption.

Risks: weak audit trail, no release tags, unclear ownership, no isolated CI and high risk of silent consumer breakage.

## Recommended Decision

Adopt Option C as the target: create a Smart3AI platform repository that contains `design-system`, shared tooling, documentation, harnesses and future shared packages. Keep the current shared folder only as a temporary Alpha 9 transition state.

## Reasons

The platform repository balances governance and migration cost. It enables independent ownership and release controls without forcing all products into one monorepo. It also leaves room for consumer smoke checks that run against AdminApps, ISO Smart, ISO Smart MedSupplier and Landing.

## Consequences

- The current folder remains private and unpublished during Alpha 9.
- Public entrypoints and compatibility rules are documented before repository movement.
- CI and release workflows can be designed around the package boundary.
- Consumers keep their current aliases until migration is approved.

## Risks

- Local shared-folder consumption can drift from future package consumption.
- Consumers may rely on internal CSS classes or source paths before package exports are enforced.
- Without human approval, repository movement and registry setup cannot proceed.

## Transition Plan

1. Complete Alpha 9 governance docs, public API inventory and compatibility matrix.
2. Validate package contents with `npm pack --dry-run`.
3. Add local contract, token and forbidden-import checks.
4. Define CODEOWNERS roles and release approval gates.
5. Obtain human approval for repository creation, registry strategy and migration sequence.
6. Move the package only after consumer smoke builds pass from the proposed package entrypoints.

## Requires Human Approval

- Creating a new Git repository.
- Moving files out of `/home/felipe/proyectos/design-system`.
- Converting the ecosystem into a monorepo.
- Publishing to npm, a private registry or GitHub Packages.
- Creating tags, releases, commits, pull requests or production CI changes.
