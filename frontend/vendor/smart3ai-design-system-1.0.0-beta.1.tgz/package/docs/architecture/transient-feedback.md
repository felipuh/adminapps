# Transient Feedback

Alpha 8 selects compositional feedback primitives instead of a backend-connected notification system.

Decision:

- `S3Banner` is persistent page-context feedback.
- `S3Toast` is temporary, non-critical visual feedback.
- `S3ToastViewport` handles placement only.
- `S3ToastProvider` remains an optional local placeholder for subtree composition.
- `S3OperationFeedback` renders consumer-owned operation states.

Rejected for Alpha 8:

- global notification center;
- backend notification inbox;
- WebSockets, Server-Sent Events or polling;
- persisted toasts;
- cross-tab synchronization;
- router-coupled overlays;
- permission-aware overlay orchestration.

Products continue to own status, messages, handlers and side effects. The Design System owns structure, focus, live-region semantics, tone, spacing, layering and motion.
