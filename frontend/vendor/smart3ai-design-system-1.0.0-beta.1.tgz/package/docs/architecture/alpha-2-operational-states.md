# Alpha 2 Operational State Architecture

Alpha 2 confirms the Design System can serve operational product screens without knowing product APIs.

## Boundaries

- Components receive semantic presentation props such as `tone`, `variant`, `size`, `loading` and `disabled`.
- Products keep business values, localized labels, permissions, handlers and API contracts.
- Compatibility wrappers remain valid while consumers are migrated gradually.

## Public API

All React imports must use `@smart3ai/design-system`. Styles are loaded through `@smart3ai/design-system/styles` in packaged contexts or through the existing local CSS import during the Vite alias phase.

## Reversibility

Each migrated consumer keeps local tone maps near its domain UI. Reverting a migration requires replacing presentation components only; service calls and data shaping are unchanged.
