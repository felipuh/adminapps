# Registry Strategy

Status: Proposed for Beta 1 readiness closure

## Recommendation

Use GitHub Packages as the primary private registry for `@smart3ai/design-system` during Beta and early stable adoption.

Use controlled tarballs as the temporary verification channel until the private registry, permissions and `.npmrc` flow are approved.

Do not publish publicly. Do not publish to any registry until ownership, repository import and CI gates are approved.

## Options

| Option | Benefits | Risks | Decision |
| --- | --- | --- | --- |
| GitHub Packages | Aligns package access with repository permissions, release audit, private packages and review history. | Requires authenticated `.npmrc`, token setup, local developer onboarding and GitHub availability. | Primary recommendation. |
| npm private | Native npm UX, strong SemVer behavior and simple consumer install commands. | Account administration, cost, access review and separation from repository approvals. | Viable later if GitHub Packages creates friction. |
| Internal registry | Highest control, internal availability policy and enterprise integration. | Infrastructure ownership, maintenance, backups and support burden. | Defer until package volume justifies it. |
| Controlled tarball | No infrastructure, good for isolated verification and rollback rehearsal. | Manual distribution, weak traceability, version skew and no automated access control. | Temporary only. |

## Registry-Like Verification

Before real publication exists, verification must:

1. Run `npm pack` from the package.
2. Move the tarball outside `/home/felipe/proyectos/design-system`.
3. Compute a SHA-256 checksum.
4. Install consumers only from that tarball path.
5. Rewrite temporary consumer aliases and style imports away from local source paths.
6. Run install, lint where configured and build.
7. Fail if a consumer still resolves `/home/felipe/proyectos/design-system`.

`npm run verify:consumers` implements this flow using `/tmp` and a temporary npm cache. It removes temporary copies by default and supports `--keep-temp` for diagnosis.

## Authentication Policy

Beta registry setup must use a scoped read token for consumers and a separate publish token for the release process. Local `.npmrc` files must not be committed with secrets.

## Licensing

No open source license has been approved. The package is private, internal Smart3AI software. Missing license approval is acceptable for private Beta distribution, but blocks any public publication.

