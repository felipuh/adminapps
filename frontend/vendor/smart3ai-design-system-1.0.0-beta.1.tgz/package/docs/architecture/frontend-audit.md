# Frontend Audit - Phase 3 Initial Inventory

Date: 2026-07-30

## Products

- AdminApps: Vite React JavaScript app, Tailwind, global CSS, local `EnterpriseUI`, `lucide-react` and Heroicons.
- ISO Smart: Vite React JavaScript app, Tailwind, global CSS, shared platform stylesheet imported from `design-system/styles/platform.css`.
- ISO Smart MedSupplier: Vite React JavaScript app, Tailwind, global CSS, shared platform stylesheet imported from `design-system/styles/platform.css`.
- Landing: Vite React TypeScript app, global CSS, shared platform stylesheet imported from `design-system/styles/platform.css`; marketing pages should stay token-connected in this phase.
- Design system: CSS/tokens platform evolved into a private local React ESM package.

## Duplicated Or Equivalent Components

- `CrudEmptyState`: identical in ISO Smart and MedSupplier; migrated through wrappers to `S3EmptyState`.
- `CrudErrorBanner`: identical in ISO Smart and MedSupplier except product i18n import path; migrated through wrappers to `S3InlineAlert`.
- `CrudPageHeader`: identical in ISO Smart and MedSupplier; migrated through wrappers to `S3PageHeader`.
- Buttons: current apps use `btn-primary` and equivalent local patterns; `S3Button` is available but broad button migration is deferred.
- Status badges: CSS primitives exist; `S3StatusBadge` added, broad migration deferred.
- Loading states: CSS primitives exist; `S3LoadingState` added, broad migration deferred.
- Tables, sidebars, headers and shells: duplicated patterns exist, but they are higher risk and not migrated in this cohort.

## Tooling Compatibility

- ISO Smart and MedSupplier both use Vite and can safely consume a local alias for `@smart3ai/design-system`.
- Because the shared source currently lives outside each app root, Vite aliases also pin `react` and `lucide-react` to the consuming app's installed packages.
- AdminApps also uses Vite but remains unmigrated until `EnterpriseUI` mapping is documented component-by-component.
- Landing uses TypeScript; no React component consumption was forced in this phase.

## Styling And Accessibility

- All products already consume `--s3-*` tokens via the platform stylesheet.
- Light and dark mode are token-backed through `html.dark` or `html.theme-dark`.
- Initial shared components define visible focus through existing global platform focus rules, semantic roles for alerts/loading, and accessible dismiss labels supplied by consumers.

## Constraints Observed

- Existing uncommitted changes are present across multiple product repos.
- ISO Smart also has preexisting backend changes and generated log/database noise; backend scope was intentionally untouched.
