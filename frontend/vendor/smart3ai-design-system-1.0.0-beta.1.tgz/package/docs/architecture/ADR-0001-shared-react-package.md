# ADR-0001: Shared React Component Package

Date: 2026-07-30

Status: Accepted

## Context

Smart3AI has multiple independently built product frontends: AdminApps, ISO Smart, ISO Smart MedSupplier and Landing. A CSS/token design platform already exists in `/home/felipe/proyectos/design-system`, and the current products import `styles/platform.css` from that directory.

ISO Smart and ISO Smart MedSupplier have equivalent Common CRUD components with identical implementations for empty states, error banners and page headers. AdminApps has a local `EnterpriseUI` layer that needs separate mapping before migration. Landing is marketing-oriented and should remain token-connected without being forced into operational components.

## Decision

Use `/home/felipe/proyectos/design-system` as a private local ESM package named `@smart3ai/design-system`.

For this first alpha, Vite consumers resolve the package name through a local alias to `design-system/src/index.js`. Product code imports only from `@smart3ai/design-system`. The public package entrypoint owns all supported component exports.

## Options Evaluated

- Local versioned package: selected. It works with the current independent repos, preserves a stable import path and prepares the library for future workspace or npm distribution.
- Workspace or monorepo: deferred. The repos are currently independent; forcing a workspace now would increase migration risk.
- Internal npm package: deferred. Correct long-term path, but publishing and registry authorization are outside this iteration.
- Direct relative imports: rejected. They are fragile and expose internal implementation paths.
- Shared folder with no package contract: rejected. It does not provide versioning or a clear public API.
- Symlinks or local links: deferred. They add environment variance without solving more than a Vite alias for this phase.

## Consequences

- Products can migrate incrementally while keeping existing compatibility wrappers.
- Future packaging can change behind the same import contract.
- CI/CD remains compatible because no backend, API, Docker or deployment contracts are changed.
- Each non-Vite consumer will need an equivalent resolver when it starts importing React components.

## Guardrails

- Public imports must come from `@smart3ai/design-system`.
- Shared components must consume `--s3-*` tokens through platform CSS.
- Shared components must receive product text through props or children.
- Shared components must not import product services, permissions, i18n instances or domain models.
- Deprecated local components remain until every consumer is migrated and verified.
