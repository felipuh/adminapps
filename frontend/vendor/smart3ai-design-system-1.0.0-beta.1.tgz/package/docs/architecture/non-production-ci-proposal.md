# Non-Production CI Proposal

Status: Proposed only. Do not connect to production CI yet.

## Scope

The future platform repository should run a non-production pipeline for `packages/design-system`. It must not deploy, publish, tag or mutate product repositories.

## Pipeline

1. Install with npm.
2. Run lint and public API checks.
3. Run tests.
4. Run build.
5. Validate public contract.
6. Validate tokens.
7. Validate forbidden imports.
8. Run cycle check when a cycle tool is approved.
9. Run `npm pack --dry-run`.
10. Generate a tarball.
11. Validate package boundary and allowed files.
12. Run consumer smoke matrix from temporary copies.

## Consumer Matrix

The matrix should include AdminApps, ISO Smart, ISO Smart MedSupplier and Landing. Each job records consumer name, React range, bundler, install command, lint result, build result, warnings, duration and temporary workspace path.

## Safety Rules

The pipeline must not:

- Publish to npm or GitHub Packages.
- Commit lockfile changes.
- Push branches.
- Modify product repositories in place.
- Use `--legacy-peer-deps` for passing checks.
- Read `.env` values or production secrets.

## Future Activation

Activate only after the platform repository is approved and imported. Until then, keep this as documentation plus local `npm run verify:consumers`.

