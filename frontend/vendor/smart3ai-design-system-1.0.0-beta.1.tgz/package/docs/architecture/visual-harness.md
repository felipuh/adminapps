# Visual Harness

Alpha 5 resolves authenticated visual review constraints with a design-system-local fixture harness:

```text
docs/harness/alpha-5-table-preview.html
```

Alpha 6 extends that model for data interaction patterns:

```text
docs/harness/alpha-6-data-interactions-preview.html
```

Alpha 7 extends the harness again for layout foundations:

```text
docs/harness/alpha-7-layout-foundations-preview.html
```

## Decision

Use static preview pages inside the design system documentation. They import `styles/platform.css` and render fictitious table rows, actions, pagination, table states, search, filters, active chips, summaries, sorting, selection, bulk action states, page layout, breadcrumbs, panels and layout primitives.

## Protection

- No product route is added.
- No backend route is added.
- No token, secret or session is required.
- No API call is made.
- No production data is represented.
- Fixture rows are hardcoded and clearly labeled.
- The harness is documentation-only and is not imported by product apps.

This keeps visual acceptance unblocked without simulating production authorization or touching authentication.
