# Data Interaction Patterns

Alpha 6 adds shared presentation for interacting with collections while keeping data ownership in each product.

## Principle

The design system renders controls and emits events. Products own state, hooks, API calls, query params, permissions, translations, persistence, navigation, loading and error behavior.

No `S3Table` monolith was added. Search, filters, active chips, summaries, sorting, selection and bulk actions compose around any collection layout.

## Implemented Primitives

- Search: `S3SearchInput`
- Toolbar and filters: `S3DataToolbar`, `S3FilterBar`, `S3FilterGroup`, `S3FilterSelect`, `S3FilterCheckbox`
- Active criteria: `S3ActiveFilters`, `S3FilterChip`, `S3ClearFiltersButton`
- Results: `S3ResultsSummary`, `S3FilteredResultsNotice`
- Sorting: stronger `S3TableHeader` with `aria-sort`, sort icon states and `sortLabel`
- Selection: `S3SelectionCheckbox`, `S3SelectionCell`, selected row styling, `S3SelectionSummary`, `S3BulkActionsBar`

## Explicit Boundaries

The design system does not debounce, fetch, mutate, serialize filters, build URLs, manage permissions, reset pagination, persist saved views, select across remote results, export data or infer business labels.

## Accessibility

Controls provide labels, keyboard-operated buttons, focus-visible styles, `fieldset`/`legend` grouping where useful, `aria-sort` for sortable headers and polite summaries for result/selection updates.
