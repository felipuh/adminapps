# Data Table Discovery

## Scope

This document began in Alpha 4 and was expanded in Alpha 5 to identify safe table primitive pilots. It does not introduce `S3DataTable`.

## AdminApps

| Area | Current pattern | Discovery |
| --- | --- | --- |
| Library | Product `EnterpriseUI.DataTable` wrapper | Native `<table>` wrapped by overflow container. |
| Styling | `table-glass` in AdminApps CSS | Product-specific density, borders and hover. |
| Consumers | Organizations table and dashboard-adjacent listings | Shared wrapper imports preserve product API. |
| Search | `EnterpriseUI.SearchInput` | Product-owned search value/onChange. |
| Status | `EnterpriseUI.StatusBadge` | Alpha 4 wrapper now delegates visual badge to `S3StatusBadge`. |
| Loading/empty/error | EnterpriseUI states | Loading wrapped in Alpha 4; empty/error remain product-owned. |
| Remote data | Page/service owned | Must remain in product/domain layer. |
| Actions | Row actions and page actions | Must remain product-owned until action contract is audited. |

### Alpha 5 Classification

| Candidate | Classification | Decision |
| --- | --- | --- |
| `EnterpriseUI.DataTable` wrapper | Simple and safe | Pilot wrapper only; existing children and product page logic preserved. |
| `UsersPage` table | Intermediate | Not migrated because page-level administration behavior is broader than wrapper pilot. |
| `FinancePage` tables | Complex/domain-specific | Not migrable in Alpha 5 due to financial workflows and multiple table variants. |
| `OrganizationDetailPage` tables | Complex/domain-specific | Not migrable in Alpha 5 due to detail-page domain actions and nested contexts. |

## ISO Smart

| Area | Current pattern | Discovery |
| --- | --- | --- |
| Library | Native tables in feature pages | Tables vary by module and local Tailwind classes. |
| Styling | `enterprise-table`, direct Tailwind table classes | Some shared CSS primitives exist but usage is not uniform. |
| Pagination | Present in context signal/alert panels | Page-owned filters and page change callbacks. |
| Filters/search | Product feature state | Domain-specific filter payloads and query params. |
| Status | Mixed local badges and `S3StatusBadge` in migrated improvement cohort | Badge primitives are shareable; status mapping remains local. |
| Loading/empty/error | Mixed local and S3 wrappers | Visual primitives are shareable; data behavior remains local. |
| Actions | Edit/delete/workflow buttons | Domain permissions and handlers stay product-owned. |

### Alpha 5 Classification

| Candidate | Purpose | Pagination | Sorting | Filters/Search | Actions | Classification | Decision |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `features/improvement/pages/ImprovementCorrectiveActionsPage.jsx` | Corrective action register | None in table | None | Page/form owned | Edit/delete product handlers | Simple and safe | Migrated presentation primitives only. |
| `features/improvement/pages/ImprovementNonconformitiesPage.jsx` | Nonconformity register | None in table | None | Page/form owned | Edit/delete product handlers | Simple but already locally changed | Deferred to avoid broadening dirty-file edits. |
| `components/Documents/DocumentList.jsx` | Document listing | Product owned | Product owned | Product owned | Document workflows | Intermediate | Not migrated in Alpha 5. |
| `components/Settings/UsersManagement.jsx` | User administration | Product owned | Product owned | Product owned | Permission-sensitive | Complex/domain-specific | Not migrable in Alpha 5. |
| Planning and operations tables | Domain registers | Mixed | Mixed | Mixed | Domain actions | Intermediate to complex | Not migrable in Alpha 5. |

## ISO Smart MedSupplier

| Area | Current pattern | Discovery |
| --- | --- | --- |
| Library | Native tables in MedSupplier dashboard/workspace and inherited ISO feature pages | Workspace table derives columns from section metadata. |
| Styling | `enterprise-table`, local responsive overflow | Good candidate for future visual primitive extraction. |
| Status | `S3StatusBadge` in MedSupplier dashboard/workspace | Tone mapping stays local via `statusTone(...)`. |
| Loading/empty/error | `S3LoadingState`, `CrudEmptyState`, `CrudErrorBanner` | Existing S3 adoption can guide table states. |
| Filters/search | Section/workspace and domain modules | Domain owned. |
| Workflow actions | Per-row workflow buttons | Must remain product-owned because permissions, disabled reasons and audit prompts vary by action. |
| Remote data | `medsupplierService` | Product service layer remains out of scope. |

### Alpha 5 Classification

| Candidate | Purpose | Pagination | Sorting | Filters/Search | Actions | Classification | Decision |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `features/medsupplier/pages/MedSupplierDashboard.jsx` account table | Customer 360 summary | None in table | None | Dashboard owned | None in row | Simple and safe | Migrated presentation primitives only. |
| `features/medsupplier/pages/MedSupplierWorkspace.jsx` overview table | Section workspace listing | Product owned | Metadata driven | Section/search owned | Workflow actions | Intermediate/domain-specific | Not migrated in Alpha 5. |
| `features/medsupplier/pages/MedSupplierWorkspace.jsx` records table | Regulatory workspace records | Product owned | Metadata driven | Section/search owned | Workflow buttons and confirmations | Complex/domain-specific | Not migrable in Alpha 5. |
| Inherited ISO feature tables | Domain registers | Mixed | Mixed | Mixed | Domain actions | Intermediate to complex | Not migrable in Alpha 5. |

## Shared Primitive Candidates

- Table shell/container with horizontal overflow and tokenized border/background.
- Header cell/body cell typography, spacing and borders.
- Empty, loading and error slots using existing S3 operational states.
- Badge slot pattern while keeping status-to-tone mapping local.
- Responsive density tokens.

## Behavior Candidates

- Keyboard focus treatment for row action clusters.
- Accessible sort button primitive, if products already expose sort state.
- Pagination display primitive, if page and total semantics can be normalized.

## Product Adapters Required

- Column definitions and renderers.
- Remote query/pagination/filter adapters.
- Row permission/action adapters.
- Bulk selection and exports, where product-specific authorization applies.

## Must Stay Domain-Owned

- API calls, payloads and query params.
- Permission checks and disabled conditions.
- Workflow actions, audit reasons and business validation.
- Navigation after row actions.
- Domain-specific exports.

## Out Of Scope For Alpha 4

- Shared `S3DataTable`.
- Remote sorting/filtering/pagination framework.
- Bulk actions.
- Virtualization.
- Column configuration.
- Export.
