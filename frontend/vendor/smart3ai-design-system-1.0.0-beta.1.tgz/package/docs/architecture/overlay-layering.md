# Overlay Layering

Alpha 8 defines shared visual layers without creating a global overlay manager.

Layer tokens:

- `--s3-layer-base: 0`
- `--s3-layer-sticky: 100`
- `--s3-layer-dropdown: 300`
- `--s3-layer-popover: 500`
- `--s3-layer-drawer: 700`
- `--s3-layer-modal: 800`
- `--s3-layer-toast: 900`

Rules:

- components use tokens, not arbitrary `z-index` values;
- dialogs and drawers render in portals and lock document scroll;
- popovers and tooltips remain local to their trigger;
- toasts render in `S3ToastViewport`;
- products own open state, copy, handlers, permissions, route changes and API calls.

Portal strategy:

`S3Dialog` and `S3Drawer` create a temporary portal node in `document.body` when no container is provided. Consumers may provide a custom `container` for tests or embedded contexts. Temporary nodes are removed on unmount.

Scroll lock:

Blocking overlays use a small reference counter so nested or sequential overlays restore body overflow and scrollbar compensation only when the last blocking overlay closes.
