# Runtime Compatibility

Version: `1.0.0-alpha.10`

## Peer Dependencies

| Package | Supported range | Classification | Notes |
| --- | --- | --- | --- |
| `react` | `>=19.0.0` | peerDependency | Must be provided by consumer to avoid duplicate React. |
| `react-dom` | `>=19.0.0` | peerDependency | Required for portals and DOM rendering. |
| `lucide-react` | `^0.554.0 || ^1.0.0` | peerDependency | Consumers currently use `0.554.x` through `1.21.x`; package imports icons from consumer install. |

## Runtime Dependencies

The design-system package has no direct runtime `dependencies` in Alpha 10. Keep React, React DOM and icon libraries as peer dependencies while the package is consumed through product bundlers.

## Dev Tooling

Tests use Node ESM scripts. No test framework dependency is required for the current contract checks.

## CSS

CSS is distributed as side-effectful entrypoints. Consumers must import platform CSS once before product styles.

## Known Constraints

- Current source checkouts alias `@smart3ai/design-system` to `../../design-system/src/index.js`.
- Alpha 10 package verification installs the tarball in isolated consumer copies to validate the `exports` map before replacing source aliases permanently.
- Do not bundle a second copy of React.
- Do not widen peer ranges below React 19 without explicit compatibility testing.
