# Phase 3 Alpha 2 Migration Notes

## Migrated

- ISO Smart `ImprovementNonconformitiesPage`: section loader, severity badge, status badge, submit button and cancel button.
- ISO Smart `ImprovementCorrectiveActionsPage`: section loader, status badge, submit button and cancel button.
- ISO Smart MedSupplier `MedSupplierDashboard`: page section loader and account status badge.
- ISO Smart MedSupplier `MedSupplierWorkspace`: record section loader, private cockpit loader, forecast status badge, generic `status` columns, create button, refresh buttons and record form submit/cancel buttons.

## Preserved

- CRUD wrappers from alpha.1 remain active and compatible: `CrudEmptyState`, `CrudErrorBanner`, `CrudPageHeader`.
- Delete handlers, confirmation flows, permissions, navigation, loading state sources and API payloads were not changed.
- AdminApps was mapped but not migrated because EnterpriseUI has product-specific API and visual assumptions.

## Wrapper Status

- `CrudEmptyState`: migration in progress.
- `CrudErrorBanner`: migration in progress.
- `CrudPageHeader`: migration in progress.
- No wrapper is deprecated or removed in alpha.2.

## Pending Duplicates

- Product-local DataTable, modal, header, sidebar, filters, pagination, dashboards and workflow buttons remain intentionally duplicated.
- AdminApps page-local finance/subscription badges remain outside this cohort.

## Landing Validation Policy

Landing is marketing-facing and does not consume operational components in alpha.2. Validation must avoid overwriting the preexisting `dist` churn; use TypeScript checks and, where needed, an isolated build output directory.
