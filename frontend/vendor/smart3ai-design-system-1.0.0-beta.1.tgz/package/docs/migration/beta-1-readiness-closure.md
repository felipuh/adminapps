# Beta 1 Readiness Closure

Status: Closed with restrictions

## Executive Summary

`@smart3ai/design-system@1.0.0-alpha.10` is ready for `1.0.0-beta.1` promotion with operational restrictions. The closure work identified the clean-install blocker as the `lucide-react` peer range and the package CSS subpath, not React, React DOM or `react-is`. The package manifest now declares the supported icon major families explicitly: `^0.554.0 || ^1.0.0`, and the CSS package contract includes `@smart3ai/design-system/styles/platform.css`.

`react-is` is required by `recharts` in AdminApps, ISO Smart and ISO Smart MedSupplier. It is not imported by the Design System and should not be added to the Design System.

## Initial State

- `design-system`: local folder, not an independent git repository.
- AdminApps: existing local changes present before this phase.
- ISO Smart: existing frontend, backend and SQLite changes present before this phase.
- ISO Smart MedSupplier: existing frontend changes present before this phase.
- Landing: existing `dist` and style changes present before this phase.

Consumer repositories were not modified permanently.

## Peer Conflicts

| Consumer | Package | Installed range | Required range | Classification | Result |
| --- | --- | --- | --- | --- | --- |
| AdminApps | `lucide-react` | `^1.21.0` | Design System previously `>=0.554.0` | Design System peer declaration too broad/ambiguous for clean tarball resolution | Corrected to `^0.554.0 || ^1.0.0`. |
| ISO Smart | `lucide-react` | `^0.554.0` | Design System previously `>=0.554.0` | Design System peer declaration too broad/ambiguous for clean tarball resolution | Corrected to `^0.554.0 || ^1.0.0`. |
| ISO Smart MedSupplier | `lucide-react` | `^0.554.0` | Design System previously `>=0.554.0` | Same as ISO Smart | Corrected to `^0.554.0 || ^1.0.0`. |
| Landing | `lucide-react` | `^1.21.0` | Design System previously `>=0.554.0` | Applies if Landing begins importing React components; current usage is CSS/tokens | Corrected at package level. |

No `--legacy-peer-deps` is accepted as a final solution.

## React and React DOM

The Design System imports React from `react` and does not bundle React or React DOM. It declares both as peers with `>=19.0.0`. Current consumers declare React 19 and React DOM 19 ranges.

The package has no direct runtime dependencies, so duplicate React runtimes should not be introduced by the package. Runtime smoke remains required before final GO.

## React-Is

`react-is` is present through `recharts`:

- AdminApps: `recharts@3.8.1` includes `react-is@18.3.1`.
- ISO Smart: `recharts@3.5.1` includes `react-is@19.2.0`.
- ISO Smart MedSupplier: `recharts@3.5.1` includes `react-is@19.2.0`.
- Landing: no `recharts` dependency and no `react-is` requirement.

Decision: `react-is` belongs to the consumer graph through `recharts`, not to `@smart3ai/design-system`. If a future clean install drops it, fix the consumer lockfile or `recharts` dependency resolution. Do not add `react-is` to the Design System as dependency, peer dependency or dev dependency.

## Corrections Performed

- Updated `package.json` peer dependency for `lucide-react`.
- Added explicit `./styles/platform.css` package export for Vite/PostCSS consumers.
- Reworked `npm run verify:consumers` to pack the Design System into `/tmp`, install from the tarball in temporary consumer copies, avoid original `node_modules` and `dist`, record matrix fields and support `--keep-temp`.
- Added registry strategy, package manager policy, CI proposal and draft Beta release notes.

## Clean Install Result

Final command:

```bash
npm run verify:consumers -- --keep-temp
```

Result: pass without `--legacy-peer-deps`.

Tarball checksum:

```text
c3490a9bfbcfca5b3fba1c0921bcbe8758cfa2c1d07ec35b3437becc8cbae6c5  smart3ai-design-system-1.0.0-alpha.10.tgz
```

| Consumer | Install | Lint | Build | Result |
| --- | --- | --- | --- | --- |
| AdminApps | Pass | Pass | Pass | Pass |
| ISO Smart | Pass | Pass | Pass | Pass |
| ISO Smart MedSupplier | Pass | Pass | Pass | Pass |
| Landing | Pass | Not configured | Pass | Pass |

Temporary evidence root: `/tmp/smart3ai-consumers-afOUtu`.

## Runtime Smoke

Temporary Vite runtime smoke app imported the packed tarball, React components and `@smart3ai/design-system/styles/platform.css`.

Validated component coverage:

- `S3Button`
- `S3Input`
- `S3Table`
- `S3PageLayout`
- `S3Dialog`
- `S3ToastProvider`
- CSS import
- Dark-mode document class

Result: pass. No duplicate React or invalid hook call appeared during Vite build. Direct Node SSR is not a supported runtime for the current source package because public exports point to `.jsx` files intended for Vite/bundler consumers.

## Consumer Corrections Recommended

- Replace local Vite aliases with package resolution when registry adoption starts.
- Replace local CSS path imports with `@smart3ai/design-system/styles/platform.css` in planned consumer branches. The shorter `@smart3ai/design-system/styles` export remains available for tools that honor package exports, but current Vite/PostCSS consumer builds require the explicit CSS file path.
- Update consumer lockfiles deliberately during registry migration.
- Do not add manual `react-is` unless a direct consumer dependency starts importing it.

## Lockfile Behavior

Current local checkouts use aliases and local CSS imports, so lockfiles do not fully represent package consumption. Registry adoption will require normal `npm install @smart3ai/design-system@...` in each consumer branch and committed lockfile updates.

## Registry and Repository

Registry recommendation: GitHub Packages primary, controlled tarball temporary.

Repository recommendation: Smart3AI platform repository with `packages/design-system`, shared tooling and future shared packages. Do not execute migration in this phase.

## Ownership

Beta requires Product Platform Owner approval, technical frontend review, affected consumer validation, accessibility validation for relevant changes and green quality gates.

## CI

Non-production CI is documented in `docs/architecture/non-production-ci-proposal.md`. It is not connected to production and performs no publish/deploy actions.

## Package Manifest

Validated fields:

- Name: `@smart3ai/design-system`
- Version: remains `1.0.0-alpha.10`
- Private: `true`
- Type: `module`
- Entrypoints: `main`, `module`, `exports`
- Files: source, CSS, tokens, docs, scripts and top-level docs
- Side effects: CSS files only
- Peers: React, React DOM, lucide-react
- Dependencies: none
- Engines: not declared until supported versions are proven

## Licensing

No open source license is approved. The package remains private and internal. This is acceptable for private Beta, but blocks public publication.

## Quality Gates

Required before final GO:

- `npm test`
- `npm run pack:dry-run`
- `npm run verify:consumers`
- Runtime smoke for representative components and styles
- Secrets check before publishing is authorized

## Restrictions and Risks

- Real registry not created.
- Repository migration not executed.
- CI not connected.
- Runtime smoke still must be rerun after clean install passes.
- Product lockfile migration is pending.

## Dictum

Final dictum: GO WITH RESTRICTIONS for `1.0.0-beta.1`.

Promotion is recommended after human approval because all technical clean-install, consumer build and runtime smoke checks passed. Remaining restrictions are operational: registry creation, platform repository migration and CI activation are not executed yet.

## Integrity Confirmations

Backend, APIs, contracts, models, permissions, business logic and database were not modified by this closure work.

No `git init`, commit, push, merge, PR, tag, release, publication, `npm publish` or deploy was performed.
