# Alpha 8 Delivery Report

Version: `1.0.0-alpha.8`

Initial state:

- AdminApps had existing uncommitted frontend changes in `EnterpriseUI.jsx`, `index.css`, `OrganizationsPage.jsx` and `vite.config.js`.
- ISO Smart had existing uncommitted frontend and backend changes, including `backend/settings.py`, `backend/test_default.sqlite3` and `backend/logs/`.
- ISO Smart MedSupplier had existing uncommitted frontend changes.
- Landing had existing generated `dist` changes and `src/styles.css` changes.
- Design System is not a Git repository; an initial file inventory and checksum pass was taken before edits.

Architecture selected:

- compositional primitives with controlled open state;
- optional local toast composition only;
- no backend-connected manager;
- no permissions, routing, persistence or notification subscriptions.

Components created:

- `S3Dialog` and subcomponents;
- `S3Drawer` and subcomponents;
- `S3Tooltip`;
- `S3Popover`;
- `S3Banner`;
- `S3Toast`, `S3ToastViewport`, `S3ToastAction`, `S3ToastProvider`;
- `S3OperationFeedback`.

Components expanded:

- `S3ConfirmationDialog` now renders through `S3Dialog` while preserving its public props and behavior.

Pilots:

- ISO Smart: `CrudErrorBanner` now uses `S3Banner tone="danger"` while preserving the same `message`, localized dismiss label and close handler.
- MedSupplier: existing `MedSupplierWorkspace` `S3ConfirmationDialog` path validates the refactor without changing product handlers, loading state, permissions or service calls.
- AdminApps: `EnterpriseUI` adds low-risk wrapper exports for `Banner`, `Tooltip`, `Popover`, `Toast`, `ToastViewport` and `ToastAction`; no page flow is changed until a page opts in.

Out of scope confirmed:

- no backend changes were made by Alpha 8;
- no APIs, REST contracts, models, serializers, migrations, permissions, authentication, database, Docker, NGINX, Ansible or CI/CD were changed by Alpha 8;
- no `git init`, commit, push, merge, PR, tag, release, npm publish or deploy was performed.

Quality gates:

- Design System `test`, `lint` and `build` passed through `node tests/public-api.test.mjs`.
- ISO Smart frontend `lint` and `build` passed.
- ISO Smart MedSupplier frontend `lint` and `build` passed; lint emitted the existing Babel note for the large `src/i18n/messages.js` file.
- AdminApps frontend `lint` and `build` passed; build emitted the existing Rolldown plugin timing advisory.
- Landing TypeScript check passed with `tsc -b --noEmit`; `npm run build` was intentionally not run to avoid overwriting the preexisting dirty `dist` output.
- Persistent harness screenshots were captured in `docs/evidence/alpha-8/`.

Risks and limitations:

- deeper product migrations should wait until the existing dirty working trees are reviewed;
- tooltips and popovers use simple local positioning in Alpha 8 and do not include collision flipping;
- the toast provider is deliberately non-stateful pending real subtree needs.

Alpha 9 recommendation:

- add collision-aware floating placement if real popover usage grows;
- consider a removable local toast queue hook only after two product pilots prove duplicated code;
- expand product pilots once dirty working-tree ownership is clear.
