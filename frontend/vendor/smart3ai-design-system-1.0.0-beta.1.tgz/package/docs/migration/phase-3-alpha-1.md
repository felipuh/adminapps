# Phase 3 Alpha 1 Migration Notes

## Migrated

- ISO Smart `CrudEmptyState` now renders `S3EmptyState`.
- ISO Smart `CrudErrorBanner` now renders `S3InlineAlert`.
- ISO Smart `CrudPageHeader` now renders `S3PageHeader`.
- ISO Smart MedSupplier `CrudEmptyState` now renders `S3EmptyState`.
- ISO Smart MedSupplier `CrudErrorBanner` now renders `S3InlineAlert`.
- ISO Smart MedSupplier `CrudPageHeader` now renders `S3PageHeader`.

## Compatibility Strategy

Existing page imports remain unchanged for this iteration. The compatibility wrappers allow rollback by editing three files per product and avoid a broad page migration.

## Deprecation Status

- `CrudEmptyState`: migration in progress; official replacement is `S3EmptyState`.
- `CrudErrorBanner`: migration in progress; official replacement is `S3InlineAlert`.
- `CrudPageHeader`: migration in progress; official replacement is `S3PageHeader`.

The old component filenames are not removed because many product pages still import them.

## Next Cohort

- Replace local status badge patterns with `S3StatusBadge`.
- Introduce direct product imports from `@smart3ai/design-system` for new pages.
- Map AdminApps `EnterpriseUI` to official component responsibilities before migration.
- Defer tables, sidebar, header and app shell until primitives are stable.
