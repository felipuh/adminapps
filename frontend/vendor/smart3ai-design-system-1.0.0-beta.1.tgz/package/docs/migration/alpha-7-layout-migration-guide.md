# Alpha 7 Layout Migration Guide

1. Import shared primitives from `@smart3ai/design-system`.
2. Wrap page content with `S3PageLayout` and `S3PageContent`.
3. Keep product routes, permissions, loaders, handlers, API calls and translations unchanged.
4. Use `S3ContentSection` only for real page sections with product-owned labels.
5. Use `S3Breadcrumbs` only with consumer-provided items.
6. Use `S3ActionBar` for layout of already-authorized actions, not for permission logic.
7. Use `S3Panel` only when an existing section already has panel semantics.

Avoid dirty files, dashboards with specialized layouts, shells, sidebars, topbars and pages with parallel work.
