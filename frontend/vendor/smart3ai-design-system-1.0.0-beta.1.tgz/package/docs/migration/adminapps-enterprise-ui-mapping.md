# AdminApps EnterpriseUI Compatibility Mapping

## Inventory Matrix

| AdminApps EnterpriseUI | Smart3AI Library | Estado |
| --- | --- | --- |
| `PageLayout` | `S3PageLayout` | Activo: wrapper Alpha 7 |
| `PageContent` | `S3PageContent` | Activo: wrapper Alpha 7 |
| `PageHeader` | `S3PageHeader` | Compatible con adaptacion |
| `SectionHeader` | `S3SectionHeader` | Compatible con adaptacion |
| `ActionBar` | `S3ActionBar` | Activo: wrapper Alpha 7 |
| `Card` | `S3Panel` | Activo: wrapper Alpha 7 |
| `MetricCard` | Futuro | Especifico de AdminApps por ahora |
| `StatusBadge` | `S3StatusBadge` | Activo: wrapper Alpha 4 |
| `EmptyState` | `S3EmptyState` | Compatible con adaptacion |
| `LoadingState` | `S3LoadingState` | Activo: wrapper Alpha 4 |
| `ErrorState` | `S3ErrorState` / `S3InlineAlert` | Compatible con adaptacion |
| `SearchInput` | `S3SearchInput` | Activo: wrapper Alpha 6 |
| `DataTable` | `S3TableContainer` + `S3Table` | Activo: wrapper Alpha 5 |
| `FilterBar` | `S3FilterBar` | Activo: wrapper Alpha 6 |
| `FilterSelect` | `S3FilterSelect` | Activo: wrapper Alpha 6 |
| `ActiveFilters` | `S3ActiveFilters` | Activo: wrapper Alpha 6 |
| `FilterChip` | `S3FilterChip` | Activo: wrapper Alpha 6 |
| `ResultsSummary` | `S3ResultsSummary` | Activo: wrapper Alpha 6 |
| `SortableHeader` | `S3TableHeader` | Disponible; usar solo donde ya exista sorting |
| Page-local `input` controls | `S3Input` + `S3FormField` | Compatible con adaptacion |
| Page-local `label` text | `S3FieldLabel` / `S3FormField` | Compatible con adaptacion |
| Page-local field errors | `S3FieldError` / `S3FormField error` | Compatible mediante wrapper |
| Page-local `textarea` controls | `S3Textarea` + `S3FormField` | Compatible con adaptacion |
| Page-local native `select` controls | `S3Select` + `S3FormField` | Compatible con adaptacion |
| Page-local checkbox controls | `S3Checkbox` | Compatible con adaptacion |
| Page-local radio controls | `S3Radio` | Compatible con adaptacion |
| Toggle-like booleans | `S3Switch` | Requiere revision semantica |
| Simple confirmation modals | `S3ConfirmationDialog` | Compatible mediante wrapper |
| Page banners | `S3Banner` | Compatible mediante wrapper Alpha 8 |
| Icon help | `S3Tooltip` | Compatible mediante wrapper Alpha 8 |
| Lightweight contextual panels | `S3Popover` | Compatible mediante wrapper Alpha 8 |
| Local visual toasts | `S3Toast` + `S3ToastViewport` | Compatible solo por subtree |
| Complex modals/drawers | Futuro | No migrar |
| Submit/cancel buttons | `S3Button` | Compatible con adaptacion |
| Form layouts | Product layout + shared fields | Especifico de AdminApps por ahora |

## API Differences

- AdminApps `StatusBadge` accepts business-like `status` values and maps them internally. `S3StatusBadge` accepts visual `tone`; business mapping must move to AdminApps or to a local wrapper.
- AdminApps `PageHeader` uses `description` and `actions`; `S3PageHeader` now accepts those aliases while preserving the earlier title/subtitle/action shape used by ISO Smart wrappers.
- AdminApps `PageLayout` and `PageContent` delegate page width and vertical flow to Alpha 7 primitives while retaining the local `enterprise-page` class for compatibility.
- AdminApps `Card` delegates to `S3Panel` but keeps the `enterprise-card` class so existing visual tuning remains in the product.
- AdminApps `LoadingState` has only a `label`; `S3LoadingState` adds scoped variants and ARIA props.
- AdminApps `SearchInput` preserves its event-like wrapper contract while delegating presentation to `S3SearchInput`.
- AdminApps `FilterSelect` delegates presentation to `S3FilterSelect`; product pages still own option values and query params.
- AdminApps `DataTable` delegates only the container/table shell; row/cell semantics remain page-owned until each table is migrated safely.
- AdminApps form pages use local Tailwind labels, `input-glass`, native selects, checkboxes and page-owned modal shells. These map to Alpha 3 controls only when field names, option values, validation messages and submit handlers remain unchanged.
- AdminApps complex modals in organization, finance and subscription flows combine permissions, billing states and nested workflows. They should remain product-owned until a wrapper audit proves equivalence.
- AdminApps Alpha 8 overlay candidates should use wrappers only: `Banner`, `Tooltip`, `Popover`, `ToastViewport` and simple `ConfirmationDialog`. No AdminApps wrapper may fetch notifications, own permissions or navigate.

## Visual Differences

- EnterpriseUI uses Tailwind utility classes directly and depends on AdminApps `index.css`.
- Smart3AI components use `--s3-*` tokens through `platform.css`.
- Badge tones are visually close for success, warning, danger, info and neutral; `accent` needs AdminApps-specific review before broad migration.

## Dependencies And Consumers

- `EnterpriseUI.jsx` is consumed by `DashboardPage.jsx` and `OrganizationsPage.jsx`.
- AdminApps also has page-local badge helpers in finance, subscriptions and organization detail views.
- AdminApps form candidates include login, password reset, settings profile/password, users, organizations, finance adjustment/payment and organization-user invite flows.
- The current AdminApps CSS file had preexisting local changes before alpha.2 work began, so runtime migration was deferred.

## Risks

- Moving business-status mapping into the shared library would couple AdminApps API values to the Design System.
- Replacing DataTable early would risk sorting, density, responsive behavior and table semantics.
- Page-local finance/subscription badges may encode commercial states that need product-owner review.
- Replacing page-local form markup without wrapper tests could alter labels, disabled states, keyboard order or validation display.
- Migrating confirmation modals in billing flows could change irreversible action timing if callbacks are not preserved exactly.

## Transition Strategy

- Keep `EnterpriseUI` active.
- Create AdminApps-local wrappers only after each component has a clear tone/prop mapping.
- Use `PageLayout` and `PageContent` for simple administrative pages before considering deeper page section migrations.
- Start with `StatusBadge` or `LoadingState` wrappers, not DataTable.
- For forms, start with `ForgotPasswordPage` or `SettingsPage` profile/password sections, then create AdminApps-local wrappers for labels and `input-glass` parity.
- Migrate one AdminApps page at a time after visual parity is verified.

## Components To Keep In AdminApps

- `MetricCard`, finance/subscription detail badges, complex form layouts, billing modals and organization detail modals remain AdminApps-owned for now.

## Wrapper Candidates

- `StatusBadge` is now an active wrapper around `S3StatusBadge`; AdminApps keeps the local `status -> tone` map.
- `LoadingState` is now an active wrapper around `S3LoadingState variant="section"`.
- `EmptyState` can become a wrapper around `S3EmptyState` if icon/title/description behavior is preserved.
- `Input`, `Textarea` and `Select` wrappers can delegate to Alpha 3 controls after AdminApps keeps `input-glass` sizing parity.
- Confirmation wrappers can delegate to `S3ConfirmationDialog` for simple delete/deactivate prompts only.
- Banner, tooltip, popover and toast wrappers can delegate to Alpha 8 primitives where text, open state, duration and actions stay page-owned.

## Alpha 4 Wrapper Status

| Wrapper | Product | S3 equivalent | Active consumers | Estado | Compatibilidad | Retiro estimado |
| --- | --- | --- | --- | --- | --- | --- |
| `StatusBadge` | AdminApps | `S3StatusBadge` | `DashboardPage`, `OrganizationsPage` | activo | Directa mediante mapa local de estado a tono | Mantener hasta Alpha 5 table audit |
| `LoadingState` | AdminApps | `S3LoadingState` | `DashboardPage`, `OrganizationsPage` | activo | Directa, conserva `label` | Mantener hasta Alpha 5 table audit |
| `EmptyState` | AdminApps | `S3EmptyState` | `DashboardPage`, `OrganizationsPage` | activo | Compatible con adaptacion; conserva icono/action local por ahora | Revisar Alpha 5 |
| `DataTable` | AdminApps | `S3TableContainer` + `S3Table` | `OrganizationsPage` | activo | Shell compartido; filas siguen en producto | Mantener wrapper |
| `SearchInput` | AdminApps | `S3SearchInput` | `OrganizationsPage` | activo | Conserva firma event-like de AdminApps | Mantener wrapper |
| `FilterBar` | AdminApps | `S3FilterBar` | `OrganizationsPage` | activo | Visual solamente | Mantener wrapper |
| `FilterSelect` | AdminApps | `S3FilterSelect` | `OrganizationsPage` | activo | Opciones/params del producto | Mantener wrapper |
| `ActiveFilters` | AdminApps | `S3ActiveFilters` | `OrganizationsPage` | activo | Limpieza controlada por pagina | Mantener wrapper |
| `ResultsSummary` | AdminApps | `S3ResultsSummary` | `OrganizationsPage` | activo | Texto localizado por pagina | Mantener wrapper |
| `PageLayout` | AdminApps | `S3PageLayout` | `OrganizationsPage` | activo | Ancho/padding compartido; shell sigue en producto | Mantener wrapper |
| `PageContent` | AdminApps | `S3PageContent` | `OrganizationsPage` | activo | Flujo vertical compartido | Mantener wrapper |
| `ActionBar` | AdminApps | `S3ActionBar` | Disponible | activo | Acciones siguen autorizadas por pagina | Mantener wrapper |
| `Card` | AdminApps | `S3Panel` | `MetricCard`, `OrganizationsPage` indirecto | activo | Conserva clase `enterprise-card` | Revisar visualmente antes de ampliar |
| `Banner` | AdminApps | `S3Banner` | Ninguno runtime en Alpha 8 | candidato | Visual solamente; pagina conserva dismiss/texto | Pilotar en pagina no critica |
| `Tooltip` | AdminApps | `S3Tooltip` | Ninguno runtime en Alpha 8 | candidato | Solo ayuda breve; icon button conserva `aria-label` | Pilotar con icon button |
| `Popover` | AdminApps | `S3Popover` | Ninguno runtime en Alpha 8 | candidato | Estado y acciones de pagina | Pilotar con ayuda contextual |
| `Toast` | AdminApps | `S3Toast` | Ninguno runtime en Alpha 8 | candidato | Solo feedback local no critico | Usar por subtree, no global |

## Suggested Order

1. `LoadingState`
2. `StatusBadge`
3. `EmptyState`
4. `PageLayout` and `PageContent` on simple admin pages
5. `PageHeader`
6. Cards and metrics
7. Sortable headers only where AdminApps already owns sorting
8. Complex layout components in a later phase
