# Alpha 4 Visual Acceptance

## Scope

Representative visual acceptance targets:

- ISO Smart: Forgot Password, improvement CRUD screens using `S3PageHeader`, `S3StatusBadge`, `S3LoadingState`, empty/error wrappers.
- ISO Smart MedSupplier: Forgot Password, MedSupplier dashboard/workspace loading, badges, CRUD table, empty state and delete confirmation dialog.
- AdminApps: dashboard and organizations screens through `EnterpriseUI` wrappers for `StatusBadge` and `LoadingState`.

## Viewports

| Viewport | Size |
| --- | --- |
| Desktop large | 1440 x 900 |
| Laptop | 1280 x 720 |
| Tablet | 768 x 1024 |
| Mobile | 390 x 844 |
| Mobile small | 360 x 800 when environment permits |

## Checklist

| Area | Status | Notes |
| --- | --- | --- |
| Light mode | partially validated | Captured ISO Smart, MedSupplier and AdminApps public Forgot Password screens. ISO/MedSupplier auth shell intentionally uses a dark surface in default mode. |
| Dark mode | partially validated | Captured desktop screenshots after applying `html.dark` and `html.theme-dark`. |
| Responsive | partially validated | Captured desktop, tablet and mobile for ISO Smart and MedSupplier Forgot Password; captured AdminApps mobile after pilot. |
| Keyboard | code-inspected | `S3ConfirmationDialog` keeps Tab trap, Shift+Tab wrap and Escape cancel. Full authenticated keyboard pass requires seeded local login. |
| Focus | code-inspected | Dialog focus restoration is implemented in shared component and preserved in the MedSupplier pilot. Full browser focus pass requires authenticated workspace data. |
| Forms | partially validated | Forgot Password forms keep the same field name, value, handler, `autoComplete`, submit path and labels. |

## Findings

- AdminApps did not have a JavaScript alias for `@smart3ai/design-system`; Alpha 4 adds one matching the existing ISO Smart and MedSupplier local alias strategy.
- The MedSupplier workspace delete action was a clean confirmation candidate because it used one existing browser confirm, one existing delete service call, one existing loading flag, existing localized copy and no internal form.
- Visual defect fixed: shared field labels were too muted when placed on product-owned dark auth surfaces before global dark tokens were active. Added the shared `s3-on-dark` utility and applied it to the ISO Smart and MedSupplier Forgot Password forms.

## Evidence Generated

- `docs/evidence/alpha-4/iso-smart/desktop-light/forgot-password.png`
- `docs/evidence/alpha-4/iso-smart/desktop-dark/forgot-password.png`
- `docs/evidence/alpha-4/iso-smart/tablet/forgot-password.png`
- `docs/evidence/alpha-4/iso-smart/mobile/forgot-password.png`
- `docs/evidence/alpha-4/medsupplier/desktop-light/forgot-password.png`
- `docs/evidence/alpha-4/medsupplier/desktop-dark/forgot-password.png`
- `docs/evidence/alpha-4/medsupplier/tablet/forgot-password.png`
- `docs/evidence/alpha-4/medsupplier/mobile/forgot-password.png`
- `docs/evidence/alpha-4/adminapps/light/forgot-password.png`
- `docs/evidence/alpha-4/adminapps/dark/forgot-password.png`
- `docs/evidence/alpha-4/adminapps/after/forgot-password-mobile.png`

## Limitations

- Authenticated ISO Smart CRUD, MedSupplier workspace/dashboard and AdminApps dashboard/organizations screenshots were not captured because the local preview did not include a seeded authenticated session and safe local data.
- The AdminApps `before` visual state was documented through code/status comparison rather than screenshot because Alpha 4 does not revert or overwrite the current working tree.
