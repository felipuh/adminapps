# AdminApps Alpha 4 Pilot

## Scope

Alpha 4 performs a first low-risk AdminApps adoption through the existing `EnterpriseUI` module. Consumer pages keep importing `StatusBadge` and `LoadingState` from `../components/ui/EnterpriseUI`.

## Components Adopted

| EnterpriseUI export | Shared component | Consumers preserved | Notes |
| --- | --- | --- | --- |
| `StatusBadge` | `S3StatusBadge` | `DashboardPage`, `OrganizationsPage` | Business status mapping remains local to AdminApps. |
| `LoadingState` | `S3LoadingState` | `DashboardPage`, `OrganizationsPage` | Existing `label` prop is preserved. |

## Compatibility

- No page consumers were migrated.
- No AdminApps backend, API, routing, auth, permissions or business logic was changed.
- `DataTable`, `SearchInput`, complex modals, AppShell, sidebar, topbar and dashboards remain product-owned.
- AdminApps now uses the same local Vite alias pattern as ISO Smart to resolve `@smart3ai/design-system`.

## Risk

Risk is low because the public AdminApps component API stays stable and the wrapper only maps presentation. Visual parity should be rechecked in dashboard and organizations screens before broader adoption.
