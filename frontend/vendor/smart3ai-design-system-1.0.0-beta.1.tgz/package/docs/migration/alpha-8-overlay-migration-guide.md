# Alpha 8 Overlay Migration Guide

Migrate only low-risk visual layers first.

Good candidates:

- informational modals with controlled open state;
- existing `S3ConfirmationDialog` confirmations;
- icon-button hints;
- contextual page banners;
- short success or warning toasts;
- simple side panels for detail or filters.

Avoid in Alpha 8:

- domain-critical regulatory flows;
- complex forms inside modals;
- route-sized drawers;
- backend notification feeds;
- permission orchestration;
- global shell behavior.

Migration checklist:

- preserve handlers and state;
- preserve API calls and payloads;
- preserve copy and translations;
- wire `ariaLabelledBy` and `ariaDescribedBy`;
- verify focus starts inside the overlay;
- verify Tab/Shift+Tab stay inside dialogs and drawers;
- verify Escape and backdrop behavior;
- verify focus returns to the opener;
- verify mobile height and footer action visibility;
- verify light and dark mode.
