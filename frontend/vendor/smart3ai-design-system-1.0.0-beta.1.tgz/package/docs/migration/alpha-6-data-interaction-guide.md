# Alpha 6 Data Interaction Guide

Use Alpha 6 primitives only after confirming the target screen already has compatible interaction behavior.

## Migration Checklist

- Keep existing state, debounce, service calls, query params, pagination, permissions, translations and navigation.
- Replace only presentation wrappers and accessible labels.
- Use localized strings from the product.
- Do not introduce new filter values or rename existing query parameters.
- Do not add selection or bulk actions to screens that do not already have them.

## Safe Patterns

```jsx
<S3DataToolbar>
  <S3SearchInput value={search} onChange={setSearch} label={t('search')} />
  <S3FilterBar label={t('filters')}>
    <S3FilterSelect value={status} onChange={setStatus} label={t('status')}>
      {statusOptions}
    </S3FilterSelect>
  </S3FilterBar>
</S3DataToolbar>
```

```jsx
<S3TableHeader
  sortable
  sortDirection={sort.direction}
  sortLabel={t('sort.name')}
  onSort={() => handleSort('name')}
>
  {t('columns.name')}
</S3TableHeader>
```

## Defer

Defer screens with dependent filters, remote autocomplete, regulatory workflows, sensitive bulk actions, page-vs-all selection ambiguity or local uncommitted changes that conflict with the migration.
