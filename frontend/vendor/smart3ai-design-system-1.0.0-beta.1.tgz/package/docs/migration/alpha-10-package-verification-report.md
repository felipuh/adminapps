# Alpha 10 Package Verification Report

Date: 2026-07-31
Package: `@smart3ai/design-system@1.0.0-alpha.10`

## Scope

Alpha 10 verifies that the package can be built, packed, installed in isolation and consumed by the current Smart3AI products without relying on local source paths. It does not publish to npm, create tags, deploy, migrate repositories, alter backend code, change product routes, change product behavior or add new components.

## Protected State

The following repositories had existing local changes before verification and were treated as protected:

| Repository | Protected state |
| --- | --- |
| AdminApps | Frontend source and Vite config changes present. |
| ISO Smart | Backend settings, SQLite database, frontend source, Vite config and logs present. |
| ISO Smart MedSupplier | Frontend source and Vite config changes present. |
| Landing | Existing `dist` changes and `src/styles.css` change present. |

Consumer verification was performed from temporary copies under `/tmp`; product repositories, generated `dist` folders, databases, logs and local configs were not permanently modified.

## Package Gates

| Gate | Result | Evidence |
| --- | --- | --- |
| Public API contract | Pass | `npm test` ran `tests/public-api.test.mjs`. |
| Forbidden deep imports | Pass | `scripts/validate-boundaries.mjs` found no forbidden consumer imports. |
| Token contract | Pass | `scripts/validate-tokens.mjs` passed. |
| Build command | Pass | Package `build` is the same contract gate and passed. |
| Dry pack review | Pass | `npm pack --dry-run` reviewed 103 files before version bump. |
| Real packed artifact | Pass | `smart3ai-design-system-1.0.0-alpha.10.tgz` generated for isolated installation. |

## Tarball Contents

The packed artifact contains only the package allowlist:

- `src/`
- `styles/`
- `tokens/`
- `components/`
- `layout/`
- `docs/api/`
- `docs/architecture/`
- `docs/components/`
- `docs/compatibility/`
- `docs/governance/`
- `docs/harness/`
- `docs/migration/`
- `docs/security/`
- `README.md`
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `package.json`

No product `dist`, logs, databases, backend files, temporary directories or secrets are included.

## Isolated Consumer Verification

| Consumer | Install source | Build command | Result | Notes |
| --- | --- | --- | --- | --- |
| AdminApps | Local alpha.10 tarball | `npm run build` | Pass | Built from temporary copy with package dependency installed. The copied install required restoring existing `react-is` after npm removed it as extraneous. |
| ISO Smart | Local alpha.10 tarball | `npm run build` | Pass | Built from temporary copy with package dependency installed. The copied install required restoring existing `react-is` after npm removed it as extraneous. |
| ISO Smart MedSupplier | Local alpha.10 tarball | `npm run build` | Pass | Built from temporary copy with package dependency installed. |
| Landing | Local alpha.10 tarball | `npm run build` | Pass | TypeScript and Vite build passed from temporary copy. |

## Entrypoints

Verified package entrypoints:

- `@smart3ai/design-system`
- `@smart3ai/design-system/styles`
- `@smart3ai/design-system/tokens`

No consumer source required internal `src/`, `components/`, `layout/` or token file deep imports after isolated tarball installation. Vite validated the JSX and CSS entrypoints during production builds; direct Node imports are not a supported runtime for this source-distributed React/CSS package.

## Peer Dependencies

The package has no runtime dependencies. Consumers provide:

- `react >=19.0.0`
- `react-dom >=19.0.0`
- `lucide-react >=0.554.0`

AdminApps and Landing use newer `lucide-react` ranges that satisfy the package peer range.

## Warnings And Deferred Items

- Consumer lint is deferred for Beta closure because the acceptance gate is packaged install plus smoke build compatibility.
- Plain `npm install` in copied `node_modules` directories reported `lucide-react@undefined` during peer resolution. The consumer manifest ranges satisfy `lucide-react >=0.554.0`, and `npm install --legacy-peer-deps --no-save` installed the tarball for the isolated smoke builds. This should be retested from clean installs once registry and CI strategy are approved.
- AdminApps and ISO Smart copied installs temporarily lost `react-is`, a `recharts` runtime import that exists in the original product installs. Restoring the existing package in the temporary copies allowed both builds to pass. This is tracked as consumer dependency hygiene, not a design-system package dependency.
- Product source checkouts still contain local Vite aliases until the repository and distribution strategy is approved.
- Consumer smoke verification is not yet wired into productive CI.
- Registry, repository ownership controls, GitHub release, npm publication, tags and deployment remain out of scope.

## Decision

GO WITH RESTRICTIONS for `1.0.0-beta.1`.

The package is technically consumable from a packed artifact by the current products. Beta 1 may proceed only if Smart3AI accepts the remaining governance restrictions: no npm publication until registry approval, no permanent alias replacement until repository strategy approval, and no production release automation until non-production CI smoke checks are wired.
