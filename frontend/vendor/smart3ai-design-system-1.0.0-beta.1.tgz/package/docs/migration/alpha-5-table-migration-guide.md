# Alpha 5 Table Migration Guide

Use Alpha 5 primitives only for simple, safe tables where presentation can be separated from product-owned logic.

## Candidate Checklist

- Few columns.
- Native table or simple wrapper.
- No bulk selection.
- No inline editing.
- No drag and drop.
- No complex remote filter or sort coupling.
- Existing loading, empty and error behavior can remain in place.
- Row actions remain local to the product.

## Migration Steps

1. Keep the existing data hook, service call, query params, handlers and permissions unchanged.
2. Replace the outer overflow/table shell with `S3TableContainer` and `S3Table`.
3. Replace `thead`, `tbody`, `tr`, `th`, `td` with the corresponding `S3Table*` primitive.
4. Use `S3TableActions` only as an action layout wrapper.
5. Use `S3TableLoading`, `S3TableEmpty` or `S3TableError` only when they match the existing state behavior.
6. Validate desktop, tablet, mobile, light mode, dark mode, keyboard focus and horizontal overflow.

Do not introduce `S3DataTable`, column configuration frameworks, shared API adapters, shared permission logic or remote query behavior in Alpha 5.
