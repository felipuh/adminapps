# Alpha 2 Consumer Guide

## Alias

Vite consumers resolve the package name to the local public entry:

```js
'@smart3ai/design-system': path.resolve(__dirname, '../../design-system/src/index.js')
```

Do not import from internal component files.

## Styles

Load shared styles once from the product stylesheet:

```css
@import "../../../design-system/styles/platform.css";
```

## Imports

```jsx
import {
  S3Button,
  S3LoadingState,
  S3StatusBadge,
} from '@smart3ai/design-system';
```

## Localized Text

Pass translated labels from the product:

```jsx
<S3LoadingState variant="section" label={t('common.messages.loading')} />
```

## Status Mapping

Keep business values outside the Design System:

```jsx
const statusTones = {
  open: 'danger',
  in_progress: 'info',
  closed: 'success',
};

<S3StatusBadge tone={statusTones[item.status] || 'neutral'}>
  {statusLabels[item.status] || item.status}
</S3StatusBadge>
```

## Business Logic

Do not move permissions, handlers, query state, API payloads, workflow rules or route decisions into shared components. The Design System owns presentation contracts only.
