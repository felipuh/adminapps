# Alpha 10 Beta Readiness Roadmap

## Beta 1 Criteria

- Repository and distribution strategy approved.
- Role-based ownership approved and translated into repository controls.
- Public API inventory complete and reviewed.
- CSS and token contracts documented.
- Consumer matrix current for AdminApps, ISO Smart, ISO Smart MedSupplier and Landing.
- Contract, token and boundary checks pass.
- Package contents dry run reviewed.
- Consumer smoke builds pass from the packed package artifact in isolated copies.
- Deprecation, release, accessibility and contribution policies approved.

## Blocking Risks

- Design-system is not yet an independent Git repository.
- Publication target is not approved.
- Consumer smoke builds are not wired into productive CI.
- Clean npm install from the tarball needs a registry-backed retest because copied `node_modules` installs required legacy peer resolution and `react-is` restoration in two temporary consumers.
- Some APIs remain alpha-experimental, especially overlay feedback primitives.

## Acceptable Debt for Beta 1

- Private/unpublished package state.
- Manual changelog generation.
- Static visual harnesses instead of full Storybook or visual regression CI.
- Opt-in local consumer smoke script while CI strategy is pending approval.
- Source checkout aliases may remain until the repository and registry decision is made, because alpha.10 verifies tarball consumption without changing product repositories.

## Roadmap

1. Complete Alpha 10 packaged artifact verification.
2. Approve platform repository or alternate repository strategy.
3. Add CI contract checks in the package repository.
4. Add non-production consumer smoke checks.
5. Freeze Beta 1 public API candidates.
6. Publish only after registry and release approval.
