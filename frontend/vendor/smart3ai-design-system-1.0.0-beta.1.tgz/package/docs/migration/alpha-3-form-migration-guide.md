# Alpha 3 Form Migration Guide

## Scope

Alpha 3 covers simple native form foundations and simple confirmation dialogs. It does not cover dynamic forms, remote autocompletes, file uploads, rich text, business validators, React Hook Form or Formik adapters.

## Safe Cohort Selection

Prefer forms with few fields, stable handlers, no backend contract changes, local options, native controls and existing translations. Skip dirty or complex files unless the current change is already part of the shared-component migration.

## Migration Steps

1. Record current field names, required flags, values, handlers, errors and submit behavior.
2. Replace label/control markup with `S3FormField` and the matching native shared control.
3. Preserve every `name`, `value`, `checked`, `onChange`, `required`, `disabled`, `readOnly`, `autoComplete`, `min`, `max` and `step` prop.
4. Keep validation messages and translation keys in the product.
5. Run lint and build for the product.
6. Verify keyboard focus, labels, error association, light/dark mode and mobile width.

## Compatibility

The shared controls work with local state, native forms, manual handlers, React Hook Form and Formik because they forward refs and native props. Adapters may be added later outside this core package.

## Do Not Change

Do not change payload shape, backend field names, submit handlers, permissions, required rules, option values, post-submit navigation or business messages.

## Alpha 3 Consumer Cohort

- ISO Smart: `ForgotPasswordPage` email request form.
- ISO Smart MedSupplier: `ForgotPasswordPage` email request form.
- MedSupplier dynamic workspace forms were audited but left for a later adapter-focused phase because they are metadata-driven.

## Verification Checklist

- Field has a visible label.
- `aria-describedby` points to help/error text when present.
- `aria-invalid` appears only when invalid.
- Tab and Space work for choice controls.
- Escape and focus restoration work for confirmation dialogs.
- Light and dark token values are readable.
- No backend, API, database or migration files are modified.
