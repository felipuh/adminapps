# S3PageHeader

## Purpose

Official page header pattern for operational Smart3AI product pages.

## Import

```jsx
import { S3PageHeader } from '@smart3ai/design-system';
```

## API

- `title`: required page title.
- `subtitle`: optional supporting copy.
- `eyebrow`: optional product/platform eyebrow, defaults to `Smart3AI`.
- `action`: optional composed action area.
- `actionLabel`, `onAction`, `actionDisabled`: compatibility path for simple primary actions.

## Accessibility

Renders a semantic `header` with one visible `h1`. Product pages should avoid adding another competing `h1` in the same view.

## Migration

Replaces ISO Smart and MedSupplier `CrudPageHeader` wrappers.
