# S3ContentSection

`S3ContentSection` groups a meaningful page section with an accessible section header.

## API

- `title`, `description`, `actions`: consumer-provided content.
- `headingLevel`: semantic heading level from `1` to `6`, default `2`.
- `id`: optional heading id. If omitted, a stable React id is generated when a title exists.
- `children`: section body.

Use it for page regions that need a title, description, actions or consistent spacing. Do not use it to invent product copy.
