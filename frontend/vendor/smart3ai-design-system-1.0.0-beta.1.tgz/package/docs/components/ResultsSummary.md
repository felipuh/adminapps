# Results Summary

`S3ResultsSummary` communicates product-owned result text in a polite live region.

Prefer localized children from the consuming product. Use `S3FilteredResultsNotice` for non-intrusive notices when filters affect the visible result set.

```jsx
<S3ResultsSummary loading={loading}>
  {t('results.count', { count })}
</S3ResultsSummary>
```
