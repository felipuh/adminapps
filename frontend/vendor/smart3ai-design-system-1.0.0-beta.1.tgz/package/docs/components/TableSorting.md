# Table Sorting

`S3TableHeader` supports sortable column presentation without owning sort logic.

When `sortable` and `onSort` are provided, the header renders a button inside `th`, applies `aria-sort` from `sortDirection` and shows an ascending, descending or neutral icon. Products own the next sort state, local/remote choice and query params.

```jsx
<S3TableHeader
  sortable
  sortDirection={sort.direction}
  sortLabel={t('sort.name')}
  onSort={() => handleSort('name')}
>
  {t('columns.name')}
</S3TableHeader>
```
