# S3Popover

`S3Popover` is a lightweight controlled-or-uncontrolled primitive for small interactive content.

It supports a trigger, content region, outside click dismissal, Escape dismissal, keyboard focusability and `aria-haspopup`/`aria-expanded` on valid React triggers.

Use it for contextual help, short secondary choices and extra details. Alpha 8 does not use it for global menus, command palettes, shell navigation or route changes.
