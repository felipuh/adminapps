# S3LoadingState

## Purpose

Reusable loading indicator for panels, pages and inline async regions.

## Import

```jsx
import { S3LoadingState } from '@smart3ai/design-system';
```

## API

- `label`: accessible visible loading text.
- `size`: `sm`, `md`, `lg`.
- `variant`: `inline`, `section`, `page`, `overlay`, `skeleton`, `button`.
- `ariaLive`: defaults to `polite`.
- `ariaBusy`: defaults to `true`.
- `children`: optional extra content, including a local skeleton where the product already uses one.

```jsx
<S3LoadingState
  variant="section"
  size="lg"
  label={t('common.messages.loading')}
/>
```

## Accessibility

Renders `role="status"` with `aria-live="polite"`. Motion respects `prefers-reduced-motion`.

## Migration

Match the current loading scope. Use `section` for panels and tables, `page` only for true page-level loading, and `inline` for compact text or row loading. Do not change hooks, queries, providers or the condition that sets loading.
