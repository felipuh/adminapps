# S3Drawer

`S3Drawer` provides a controlled overlay panel for secondary detail, simple editing, supporting information and mobile-friendly panels.

Exports:

- `S3Drawer`
- `S3DrawerHeader`
- `S3DrawerBody`
- `S3DrawerFooter`

Supported sides in Alpha 8 are `start`, `end` and `bottom`.

Behavior:

- controlled `open` and `onOpenChange`;
- portal rendering;
- backdrop dismissal;
- Escape dismissal;
- focus trap and restoration;
- scroll lock;
- internal body scrolling;
- responsive bottom layout when selected by the consumer.

Do not use drawers as route replacements, global mobile sidebars, permission containers or complex editors in Alpha 8.
