# Table

Alpha 5 added semantic table primitives for product-owned data screens. Alpha 6 strengthens sorting presentation and selected-row styling. The library supplies accessible structure and visual treatment; products keep data fetching, filters, sorting state, permissions, actions and navigation.

## Public API

- `S3TableContainer`
- `S3Table`
- `S3TableHead`
- `S3TableBody`
- `S3TableFooter`
- `S3TableRow`
- `S3TableHeader`
- `S3TableCell`
- `S3TableCaption`
- `S3TableToolbar`
- `S3TableActions`

## Alpha 6 Related Exports

- `S3SelectionCell`
- `S3SelectionCheckbox`
- `S3SelectionSummary`
- `S3BulkActionsBar`

## Example

```jsx
<S3TableContainer density="comfortable">
  <S3Table>
    <S3TableCaption>{caption}</S3TableCaption>
    <S3TableHead>
      <S3TableRow>
        <S3TableHeader
          scope="col"
          sortable
          sortDirection={sort.direction}
          sortLabel={sortNameLabel}
          onSort={() => handleSort('name')}
        >
          {nameLabel}
        </S3TableHeader>
        <S3TableHeader scope="col">{statusLabel}</S3TableHeader>
        <S3TableHeader scope="col" align="end">{actionsLabel}</S3TableHeader>
      </S3TableRow>
    </S3TableHead>
    <S3TableBody>
      {rows.map((row) => (
        <S3TableRow key={row.id}>
          <S3TableCell>{row.name}</S3TableCell>
          <S3TableCell>{row.status}</S3TableCell>
          <S3TableCell align="end">
            <S3TableActions>{productActions}</S3TableActions>
          </S3TableCell>
        </S3TableRow>
      ))}
    </S3TableBody>
  </S3Table>
</S3TableContainer>
```

## Contract

- `S3Table` renders `table`.
- `S3TableHead` renders `thead`.
- `S3TableBody` renders `tbody`.
- `S3TableFooter` renders `tfoot`.
- `S3TableRow` renders `tr`.
- `S3TableHeader` renders `th` and defaults to `scope="col"`.
- `S3TableCell` renders `td`.
- `S3TableCaption` renders `caption`.
- `S3TableHeader` supports visual sortable state through `sortable`, `sortDirection` and `onSort`; the product owns the actual sort state and query behavior.
- `S3TableCell` supports `align`, `numeric`, `truncate` and `wrap` presentation flags.

## Out Of Scope

The table primitives do not call APIs, build query params, define columns from configuration, evaluate permissions, virtualize rows, persist preferences, export files, or own remote pagination/filtering/sorting.
