# S3Textarea

## Purpose

`S3Textarea` provides tokenized multiline text capture with the same neutral behavior as native `textarea`.

## Import

```jsx
import { S3Textarea } from '@smart3ai/design-system';
```

## API

Supports native textarea props plus `invalid` and `resize` (`vertical`, `horizontal`, `both`, `none`).

## Example

```jsx
<S3Textarea name="description" rows={4} value={value} onChange={handleChange} />
```

## Accessibility

Pair with `S3FormField` for labels, descriptions and error text.

## I18n

Help text, placeholders and errors remain product-owned.

## Good Practices

- Keep `rows`, `maxLength`, `disabled`, `readOnly` and `required` unchanged.
- Let the page layout control width and grouping.

## Bad Practices

- Do not add business length rules inside the component.
- Do not auto-generate domain-specific counters in Alpha 3.

## Migration Notes

Use for existing native textareas. Rich text editors remain out of scope.
