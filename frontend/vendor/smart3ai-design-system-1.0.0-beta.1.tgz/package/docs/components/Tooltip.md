# S3Tooltip

`S3Tooltip` is for short, non-critical secondary information.

It opens on hover and focus, closes on blur, pointer leave and Escape, and adds `aria-describedby` to a valid React trigger while visible.

Use tooltips for icon button clarification and compact supporting hints. Do not hide labels, errors, critical instructions or required help text inside a tooltip. Icon-only buttons still need their own `aria-label`.
