# S3SearchInput

`S3SearchInput` is a controlled search field for collection views.

It renders an accessible label, a decorative search icon, an optional clear button, disabled/loading states and Escape-to-clear behavior. It emits the next value through `onChange(value, event)` and never debounces, calls APIs, creates query params or assumes searchable fields.

```jsx
<S3SearchInput
  value={search}
  onChange={setSearch}
  label={t('common.search')}
  placeholder={t('common.searchPlaceholder')}
  clearLabel={t('common.clearSearch')}
/>
```
