# S3ActionBar

`S3ActionBar` is a compositional container for actions on a page or section.

## API

- `justify`: `start`, `center`, `end`, `between`.
- `align`: `start`, `center`, `end`, `stretch`.
- `gap`: `xs`, `sm`, `md`, `lg`, `xl`.
- `wrap`: defaults to `true`.
- `sticky`: available for proven product needs only.

It does not know permissions, action ordering, business state or routes.
