# Bulk Actions

`S3BulkActionsBar`, `S3SelectionSummary`, `S3SelectionCheckbox` and `S3SelectionCell` provide presentation for existing selection workflows.

Products keep selected IDs, permissions, page-vs-all semantics, destructive confirmations, backend calls and clear behavior.

```jsx
<S3BulkActionsBar
  count={selectedIds.length}
  summary={t('selection.count', { count: selectedIds.length })}
  onClear={clearSelection}
  clearLabel={t('selection.clear')}
>
  <S3Button onClick={handleDeactivate}>{t('actions.deactivate')}</S3Button>
</S3BulkActionsBar>
```
