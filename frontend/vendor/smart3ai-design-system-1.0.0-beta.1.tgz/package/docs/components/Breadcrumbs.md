# S3Breadcrumbs

Breadcrumbs are visual and semantic only. Products provide every item, route and label.

```jsx
<S3Breadcrumbs ariaLabel={t('navigation.breadcrumb')}>
  <S3BreadcrumbItem href="/organizations">{t('organizations.title')}</S3BreadcrumbItem>
  <S3BreadcrumbItem current>{organization.name}</S3BreadcrumbItem>
</S3Breadcrumbs>
```

`S3BreadcrumbItem` supports `href`, `as`, `current`, children and native attributes. Current items render `aria-current="page"`. The component does not read React Router, permissions or session state.

`S3BackLink` supports link and button use cases. It never calls `history.back()` by itself; the consumer must provide `href` or an explicit handler.
