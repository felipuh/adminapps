# S3PageLayout

`S3PageLayout` is the structural container for product-owned pages. It controls content width, responsive page padding and the main content boundary only.

## API

- `size`: `narrow`, `default`, `wide`, `full`.
- `as`: rendered element, default `main`.
- `children`, `className`, `ref` and native attributes pass through.

## Usage

```jsx
<S3PageLayout size="wide">
  <S3PageHeader title={title} description={description} actions={actions} />
  <S3PageContent>
    {children}
  </S3PageContent>
</S3PageLayout>
```

Routes, auth, permissions, product sidebars and global topbars remain outside this component.
