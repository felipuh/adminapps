# Active Filters

`S3ActiveFilters` and `S3FilterChip` show criteria that are already active.

Chips are keyboard-operable when removable, include accessible remove labels and wrap long values. The design system does not generate business labels or decide which filters are active.

```jsx
<S3ActiveFilters label={t('filters.active')}>
  <S3FilterChip
    label={t('filters.status')}
    value={statusLabel}
    removeLabel={t('filters.removeStatus')}
    onRemove={clearStatus}
  />
</S3ActiveFilters>
```
