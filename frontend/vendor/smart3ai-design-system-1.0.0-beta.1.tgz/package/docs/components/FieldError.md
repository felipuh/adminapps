# S3FieldError

## Purpose

`S3FieldError` renders localized field-level validation messages consistently.

## Import

```jsx
import { S3FieldError } from '@smart3ai/design-system';
```

## API

Supports `children`, `id`, `className` and ARIA props. It renders nothing when there is no message.

## Example

```jsx
<S3FieldError id="supplier-name-error">
  {t('validation.required')}
</S3FieldError>
```

## Accessibility

Errors use `role="alert"` and `aria-live="polite"` by default. Pair the ID with the control using `aria-describedby` or let `S3FormField` do it.

## I18n

The consumer supplies all message text.

## Good Practices

- Reuse existing validation messages.
- Include more than color to identify the error.

## Bad Practices

- Do not pass domain error codes and expect the Design System to translate them.

## Migration Notes

Prefer `S3FormField error={message}` unless a page needs manual composition.
