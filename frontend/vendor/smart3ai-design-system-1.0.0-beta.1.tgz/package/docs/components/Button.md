# S3Button

## Purpose

Official Smart3AI action component for standard platform buttons.

## Import

```jsx
import { S3Button } from '@smart3ai/design-system';
```

## API

- `variant`: `primary`, `secondary`, `ghost`, `danger`, `success`.
- `size`: `sm`, `md`, `lg`.
- `loading`: disables the button and shows a spinner.
- `disabled`: disables user interaction.
- `icon`: component rendered before the label. Alias: `startIcon`.
- `endIcon`: component rendered after the label.
- `as`: optional element or component for composition.
- `children`: required visible label or composed content.

`S3Button` throws when used without visible children. Use `S3IconButton` for icon-only actions:

```jsx
import { S3IconButton } from '@smart3ai/design-system';

<S3IconButton icon={RefreshCw} ariaLabel={t('common.refresh')} />
```

## Accessibility

Use meaningful button text. Loading buttons are disabled to prevent duplicate actions and keep their localized text visible beside the spinner. `S3IconButton` requires `ariaLabel` or `aria-label`.

## Migration

Alpha 2 only migrates simple CRUD actions: create/update, cancel and refresh. Do not migrate workflow actions, permission-dependent actions or icon-only controls until the icon-button audit is complete.

## Avoid

Do not pass arbitrary colors, padding, radius or inline visual styles to recreate product-specific buttons.
