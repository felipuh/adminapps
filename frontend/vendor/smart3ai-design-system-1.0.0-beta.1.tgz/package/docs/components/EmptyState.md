# S3EmptyState

## Purpose

Reusable empty-state pattern for lists, tables and panels.

## Import

```jsx
import { S3EmptyState } from '@smart3ai/design-system';
```

## API

- `title` or `message`: visible primary message.
- `description`: optional supporting text.
- `icon`: optional icon component.
- `action`: optional composed action.
- `colSpan`: renders the state inside a table row.

## Accessibility

The icon is decorative. Product text is supplied by consumers so each app can use its own translations.

## Migration

Replaces ISO Smart and MedSupplier `CrudEmptyState` wrappers.
