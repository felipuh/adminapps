# Layout Primitives

Alpha 7 adds small spatial primitives:

- `S3Stack`: vertical layout with tokenized gap and alignment.
- `S3Inline`: horizontal layout with tokenized gap, alignment, justification and wrapping.
- `S3Grid`: responsive grid using a minimum column width.

These primitives are intentionally limited. Complex product grids, split panes, dashboards and drag behavior remain product-owned.
