# S3Toast

`S3Toast` is for temporary, non-critical operation feedback.

Exports:

- `S3Toast`
- `S3ToastViewport`
- `S3ToastAction`
- `S3ToastProvider`

The toast component supports title, description, tone, dismiss, optional action, limited duration values, pause on hover/focus and screen-reader announcement. `S3ToastViewport` positions toasts using the toast layer token.

`S3ToastProvider` is intentionally local and optional in Alpha 8. It does not create a global store, fetch backend notifications, persist messages or subscribe to events.

Do not use toasts for critical errors, form validation, contractual information or high-risk confirmations.
