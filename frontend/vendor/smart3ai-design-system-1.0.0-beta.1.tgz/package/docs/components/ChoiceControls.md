# S3Checkbox, S3Radio And S3Switch

## Purpose

These components provide accessible tokenized choice controls while preserving native checked/change semantics.

## Import

```jsx
import { S3Checkbox, S3Radio, S3Switch } from '@smart3ai/design-system';
```

## API

All three support native input props plus `label`, `helpText` and `invalid`.

## Examples

```jsx
<S3Checkbox checked={enabled} onChange={handleChange} label={t('common.enabled')} />
<S3Radio name="scope" value="local" checked={scope === 'local'} onChange={handleChange} label={t('scope.local')} />
<S3Switch checked={active} onChange={handleChange} label={t('common.active')} />
```

## Accessibility

Checkbox and radio use native semantics. Switch uses native checkbox behavior with `role="switch"`.

## I18n

Labels and help text come from the product.

## Good Practices

- Keep checkbox semantics for inclusion, consent or multi-choice states.
- Use switch only for immediate binary decisions already modeled that way.

## Bad Practices

- Do not replace a checkbox with a switch for visual preference.
- Do not change boolean meaning or payload names.

## Migration Notes

Migrate one choice group at a time and verify keyboard operation with Space and Tab.
