# S3InlineAlert

## Purpose

Reusable inline alert for operational feedback and recoverable errors.

## Import

```jsx
import { S3InlineAlert } from '@smart3ai/design-system';
```

## API

- `variant`: `danger`, `warning`, `info`, `success`.
- `title`: optional alert title.
- `message` or `children`: alert body.
- `onClose`: optional dismiss action.
- `dismissLabel`: accessible label supplied by the consuming product.
- `ariaLive`: defaults to `polite`.

## Accessibility

Danger alerts render with `role="alert"`. Other variants render with `role="status"`. Dismiss buttons require localized accessible labels.

## Migration

Replaces ISO Smart and MedSupplier `CrudErrorBanner` wrappers for this phase.
