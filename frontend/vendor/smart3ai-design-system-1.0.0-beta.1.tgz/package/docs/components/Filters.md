# Filters

Alpha 6 filter primitives are visual controls for product-owned filtering.

Use `S3FilterBar`, `S3FilterGroup`, `S3FilterSelect` and `S3FilterCheckbox` to arrange localized controls. Products continue to own values, options, query params, permissions, persistence, URL state and reset behavior.

```jsx
<S3FilterBar label={t('filters.label')}>
  <S3FilterGroup label={t('filters.status')}>
    <S3FilterSelect value={status} onChange={setStatus}>
      <option value="">{t('filters.all')}</option>
      {statusOptions.map((option) => (
        <option key={option.value} value={option.value}>{option.label}</option>
      ))}
    </S3FilterSelect>
  </S3FilterGroup>
</S3FilterBar>
```
