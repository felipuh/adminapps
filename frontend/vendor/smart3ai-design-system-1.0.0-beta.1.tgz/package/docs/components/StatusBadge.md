# S3StatusBadge

## Purpose

Reusable semantic badge for statuses and compact state labels.

## Import

```jsx
import { S3StatusBadge } from '@smart3ai/design-system';
```

## API

- `tone`: `neutral`, `info`, `success`, `warning`, `danger`, `accent`.
- `status`: compatibility alias for older alpha.1 consumers.
- `icon`: optional icon component rendered before the label.
- `children`: localized visible label.

```jsx
const statusTones = {
  open: 'danger',
  analysis: 'info',
  closed: 'success',
};

<S3StatusBadge tone={statusTones[item.status] || 'neutral'}>
  {statusLabels[item.status] || item.status}
</S3StatusBadge>
```

## Accessibility

Do not communicate state by color alone. The visible label must name the state.

## I18n And Domain Mapping

The Design System never receives API-specific status values such as `vendor.status` as a semantic prop. Product code maps business state to tone and passes localized text as children.

## Migration

Alpha 2 migrated real status displays in ISO Smart improvement pages and ISO Smart MedSupplier account/workspace tables. Remaining product-specific badges should be migrated by module after their status-to-tone mapping is reviewed.
