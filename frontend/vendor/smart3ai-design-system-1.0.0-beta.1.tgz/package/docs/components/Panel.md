# S3Surface and S3Panel

`S3Surface` is a generic visual primitive for background, border, radius, shadow and padding.

`S3Panel` is a structured container with optional header, actions, body and footer.

## Variants

- `default`
- `elevated`
- `outlined`
- `muted`

Use `S3Surface` for simple framing. Use `S3Panel` when content has a clear internal header or footer. Do not automatically replace every product card with `S3Panel`.
