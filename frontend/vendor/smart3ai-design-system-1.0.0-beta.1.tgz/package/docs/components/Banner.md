# S3Banner

`S3Banner` represents persistent, page-context feedback.

Supported tones:

- `info`
- `success`
- `warning`
- `danger`

It supports title, description, localized children, optional actions, optional dismiss, tone icons and polite/assertive live-region behavior. It does not auto-dismiss unless a product explicitly removes it from render.

Use banners for visible context that should remain available while the user reviews or acts.
