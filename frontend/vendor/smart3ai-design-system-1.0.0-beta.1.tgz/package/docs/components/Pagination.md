# Pagination

`S3Pagination` is a controlled presentation component. It receives current page state and callbacks from the product and never calls APIs or changes query params itself.

## Components

- `S3Pagination`
- `S3PaginationSummary`

## Usage

```jsx
<S3Pagination
  page={page}
  pageCount={pageCount}
  onPageChange={setPage}
  previousLabel={t('common.pagination.previous')}
  nextLabel={t('common.pagination.next')}
  paginationLabel={t('common.pagination.label')}
  loading={loading}
/>
```

`page` is interpreted exactly as the product passes it. Alpha 5 does not normalize zero-based and one-based pagination contracts.
