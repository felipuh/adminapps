# S3ConfirmationDialog

## Purpose

`S3ConfirmationDialog` standardizes simple confirmations for sensitive existing actions. The consumer owns open state, copy, permissions and callbacks.

## Import

```jsx
import { S3ConfirmationDialog } from '@smart3ai/design-system';
```

## API

| Prop | Notes |
| --- | --- |
| `open` | Controls visibility. |
| `title` / `description` | Localized visible copy. |
| `confirmLabel` / `cancelLabel` | Localized action labels. |
| `tone` | `default` or `danger`. |
| `loading` / `disabled` | Prevent duplicate action. |
| `onConfirm` / `onCancel` | Consumer-owned handlers. |

## Example

```jsx
<S3ConfirmationDialog
  open={isOpen}
  title={t('confirmDelete.title')}
  description={t('confirmDelete.description')}
  confirmLabel={t('common.delete')}
  cancelLabel={t('common.cancel')}
  tone="danger"
  loading={isDeleting}
  onConfirm={handleDelete}
  onCancel={closeDialog}
/>
```

## Accessibility

The dialog uses `role="dialog"`, `aria-modal`, labelled title, optional description, Escape handling, focus trap and focus restoration.

For `tone="danger"`, initial focus moves to the cancel action so destructive confirmations require an intentional move to confirm. Escape and backdrop click call `onCancel` only while the dialog is not loading or disabled.

## Alpha 8 Refactor

`S3ConfirmationDialog` now renders through the shared `S3Dialog` primitive. Its public props, loading behavior, danger tone, confirm/cancel callbacks, focus choice and localized labels remain unchanged.

## I18n

All labels and descriptions come from the consumer.

## Good Practices

- Use for existing simple confirmations only.
- Keep API calls and permission checks outside the component.

## Bad Practices

- Do not migrate complex modals or add new confirmation steps without product approval.

## Migration Notes

Replace only the modal shell and buttons. Confirm existing callbacks, loading state and post-submit navigation remain unchanged.

## Alpha 4 Pilot

The first real pilot is ISO Smart MedSupplier workspace delete. The consumer still owns the record candidate, permission/resource guard, `medsupplierService.remove(...)`, error handling and `loadData()` refresh. The shared component owns only presentation, focus trap, Escape, backdrop cancel and accessible dialog semantics.
