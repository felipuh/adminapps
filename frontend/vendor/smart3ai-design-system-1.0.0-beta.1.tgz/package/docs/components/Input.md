# S3Input

## Purpose

`S3Input` is the shared native input foundation for common Enterprise fields. It forwards refs and native attributes while applying Smart3AI tokens.

## Import

```jsx
import { S3Input } from '@smart3ai/design-system';
```

## API

Supports native input props plus `invalid`, `prefix` and `suffix`. Use only native types already used by products: `text`, `email`, `password`, `number`, `search`, `tel`, `url` and native `date` where already present.

## Example

```jsx
<S3Input
  id="organization-name"
  name="organizationName"
  value={value}
  onChange={handleChange}
  invalid={Boolean(error)}
/>
```

## Accessibility

Use with `S3FormField` or provide your own visible label and ARIA relationships.

## I18n

Placeholder text must come from the consumer catalog.

## Good Practices

- Preserve `name`, `value`, `onChange`, `required`, `disabled` and `autoComplete`.
- Keep formatting, masks and business parsing outside the Design System.

## Bad Practices

- Do not add tax, currency or domain validation to `S3Input`.
- Do not use placeholder text as the only field name.

## Migration Notes

Swap class-heavy native inputs for `S3Input` only when the existing field is native and controlled behavior can be preserved exactly.
