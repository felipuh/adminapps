# Table States

Alpha 5 table states keep valid table structure while composing existing operational state primitives.

## Components

- `S3TableLoading`
- `S3TableEmpty`
- `S3TableError`

## Usage

```jsx
<S3TableBody>
  {loading ? (
    <S3TableLoading columnCount={5} label={t('common.messages.loading')} />
  ) : error ? (
    <S3TableError colSpan={5} title={errorTitle} description={errorMessage} action={retryButton} />
  ) : rows.length === 0 ? (
    <S3TableEmpty colSpan={5} title={emptyTitle} description={emptyDescription} />
  ) : (
    rows.map(renderRow)
  )}
</S3TableBody>
```

All labels, titles, descriptions and actions are passed by the consuming product. The design system does not include business copy or retry logic.
