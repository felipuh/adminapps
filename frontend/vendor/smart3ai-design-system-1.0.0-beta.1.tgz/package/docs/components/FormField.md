# S3FormField

## Purpose

`S3FormField` composes a localized label, one control, optional help text and optional error text. It owns accessible IDs and ARIA wiring; the consumer owns state, validation, submit behavior and translations.

## Import

```jsx
import { S3FormField, S3Input } from '@smart3ai/design-system';
```

## API

| Prop | Notes |
| --- | --- |
| `label` | Visible text or React node from the consumer. |
| `controlId` | Optional stable ID. Generated when omitted. |
| `helpText` | Optional localized help text. |
| `error` | Optional localized error text. Sets invalid ARIA on the control. |
| `required` | Mirrors native `required` on the child control. |
| `disabled` | Mirrors native `disabled` on the child control. |
| `readOnly` | Mirrors native `readOnly` where supported. |

## Example

```jsx
<S3FormField label={t('supplier.name')} error={errors.name} required>
  <S3Input name="name" value={form.name} onChange={handleChange} />
</S3FormField>
```

## Accessibility

The component associates `label` and control, merges `aria-describedby`, sets `aria-invalid` when `error` exists, and renders error text with polite live announcement.

## I18n

All visible strings must be supplied by the product. The library never generates business validation messages.

## Good Practices

- Keep field names, values and handlers in the consumer.
- Use placeholders only as hints, never as the only label.
- Pass existing validation messages through `error`.

## Bad Practices

- Do not encode domain rules in `S3FormField`.
- Do not replace product-specific layout logic with form-field props.

## Migration Notes

Replace wrapper label markup first, then move the existing input/select/textarea into `S3FormField`. Confirm the submitted payload is unchanged.
