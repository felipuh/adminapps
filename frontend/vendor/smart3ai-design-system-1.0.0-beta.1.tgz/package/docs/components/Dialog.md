# S3Dialog

`S3Dialog` is the shared modal primitive for controlled, consumer-owned dialog content.

Use it for informational modals, simple blocking decisions and low-risk composed content. The consumer owns `open`, `onOpenChange`, copy, handlers, permissions, API calls and navigation.

Exports:

- `S3Dialog`
- `S3DialogHeader`
- `S3DialogTitle`
- `S3DialogDescription`
- `S3DialogBody`
- `S3DialogFooter`
- `S3DialogClose`

Behavior:

- renders through a browser-safe portal;
- traps focus while open;
- restores focus on close;
- supports `initialFocusRef`;
- closes on Escape through `onOpenChange(false)`;
- closes on backdrop by default;
- locks document scroll while open;
- uses `role="dialog"`, `aria-modal`, labelled and described relations;
- constrains height and scrolls the body region on small screens.

Do not use `S3Dialog` to own product operations, permissions, routes, forms or backend calls.
