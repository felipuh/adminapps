# S3Select

## Purpose

`S3Select` is a native select foundation for simple local options.

## Import

```jsx
import { S3Select } from '@smart3ai/design-system';
```

## API

Supports native select props plus `invalid` and `placeholder`.

## Example

```jsx
<S3Select name="status" value={status} onChange={handleChange} required>
  <option value="draft">{t('status.draft')}</option>
  <option value="active">{t('status.active')}</option>
</S3Select>
```

## Accessibility

Use with `S3FormField` or an explicit visible label.

## I18n

Option labels and placeholders are supplied by the consumer.

## Good Practices

- Use for simple native selects with stable local options.
- Preserve controlled/uncontrolled behavior.

## Bad Practices

- Do not use for remote autocomplete, multiselect, virtualized lists or dependent API selects in Alpha 3.

## Migration Notes

Native select styling can migrate now. Complex AdminApps and MedSupplier selectors remain candidates for later wrappers.
