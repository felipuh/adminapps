# Security and Privacy Review

Alpha 9 confirms the design-system package is intended to contain UI source, CSS, tokens, docs, tests and local verification scripts only.

## Must Not Contain

- Secrets or API tokens.
- Private URLs unless required for local documentation and approved.
- Credentials.
- Real customer data.
- PII.
- Logs.
- SQLite databases.
- Temporary files.
- Product backend code.
- Production infrastructure configuration.

## Package Contents

Use `npm run pack:dry-run` before any release candidate. Review the file list for accidental product artifacts, screenshots, logs, databases, environment files or generated bundles.

## Current Alpha 9 Controls

- `package.json` `files` allowlist limits package contents.
- Contract tests verify public entrypoints and metadata.
- Boundary validation checks known consumers for forbidden deep imports.
- Token validation checks token prefix and duplicate definitions.

Publication remains out of scope until registry, repository and release approvals exist.
