# Public API

Version: `1.0.0-alpha.10`

## Entrypoints

| Name | Category | Introduced | Stability | Current consumer | Notes |
| --- | --- | --- | --- | --- | --- |
| `@smart3ai/design-system` | React entrypoint | alpha.1 | Stable candidate | AdminApps, ISO Smart, ISO Smart MedSupplier | Exports shared React primitives. |
| `@smart3ai/design-system/styles` | Style entrypoint | alpha.8 | Stable candidate | Planned package import | Maps to `styles/platform.css`. |
| `@smart3ai/design-system/styles/platform.css` | Style entrypoint | alpha.10 | Stable candidate | Required for current Vite/PostCSS package consumption | Explicit CSS file export for consumers that do not resolve extensionless CSS subpaths. |
| `@smart3ai/design-system/tokens` | Token entrypoint | alpha.8 | Stable candidate | Planned package import | Maps to `tokens/smart3ai-tokens.css`. |
| `design-system/styles/platform.css` | Style entrypoint | alpha.1 | Wrapper | All products | Current local-folder import path. |
| `design-system/tokens/smart3ai-tokens.css` | Token entrypoint | alpha.1 | Token | Landing through platform stylesheet | Canonical token file. |

## React Exports

| Name | Category | Introduced | Stability | Current consumer | Notes |
| --- | --- | --- | --- | --- | --- |
| `S3Button` | Component | alpha.1 | Stable candidate | ISO Smart, MedSupplier | Semantic button primitive. |
| `S3IconButton` | Component | alpha.2 | Stable candidate | Available | Requires accessible label. |
| `S3EmptyState` | Component | alpha.1 | Stable candidate | ISO Smart, MedSupplier | Empty state primitive. |
| `S3InlineAlert` | Component | alpha.1 | Stable candidate | MedSupplier | Inline feedback primitive. |
| `S3ErrorState` | Wrapper | alpha.1 | Stable candidate | Available | Error-state alias over alert patterns. |
| `S3LoadingState` | Component | alpha.1 | Stable candidate | ISO Smart, MedSupplier | Loading variants. |
| `S3StatusBadge` | Component | alpha.1 | Stable candidate | ISO Smart, MedSupplier | `status` remains compatibility alias for `tone`. |
| `S3FormField`, `S3FieldLabel`, `S3FieldHelp`, `S3FieldError` | Component | alpha.3 | Stable candidate | ISO Smart, MedSupplier | Field semantics and error association. |
| `S3Input`, `S3Textarea`, `S3Select`, `S3Checkbox`, `S3Radio`, `S3Switch` | Component | alpha.3 | Stable candidate | ISO Smart, MedSupplier | Consumer-owned values and handlers. |
| `S3ConfirmationDialog` | Component | alpha.3 | Stable candidate | MedSupplier | Simple confirmation wrapper over dialog base. |
| `S3Table*` exports | Component | alpha.5 | Stable candidate | ISO Smart, MedSupplier, AdminApps wrappers | Compositional table primitives. |
| `S3Pagination`, `S3PaginationSummary` | Component | alpha.5 | Stable candidate | Available | Consumer-owned pagination state. |
| `S3SearchInput`, `S3Filter*`, `S3ActiveFilters`, `S3ResultsSummary`, `S3Selection*`, `S3BulkActionsBar`, `S3DataToolbar`, `S3FilteredResultsNotice` | Component | alpha.6 | Stable candidate | AdminApps wrappers | Data interaction presentation only. |
| `S3PageLayout`, `S3PageContent`, `S3PageSection`, `S3ContentSection`, `S3SectionHeader`, `S3ActionBar`, `S3PageActions` | Component | alpha.7 | Stable candidate | ISO Smart, MedSupplier | Page composition primitives. |
| `S3Breadcrumbs`, `S3BreadcrumbItem`, `S3BackLink` | Component | alpha.7 | Stable candidate | Available | Consumer owns routes and labels. |
| `S3Surface`, `S3Panel`, `S3Stack`, `S3Inline`, `S3Grid` | Component | alpha.7 | Stable candidate | ISO Smart, MedSupplier | Layout/surface primitives. |
| `S3PageHeader` | Component | alpha.1 | Stable candidate | ISO Smart, MedSupplier | Supports legacy and alpha.7 aliases. |
| `S3Dialog`, `S3DialogHeader`, `S3DialogTitle`, `S3DialogDescription`, `S3DialogBody`, `S3DialogFooter`, `S3DialogClose` | Component | alpha.8 | Stable candidate | Confirmation dialog wrapper | Blocking overlay primitives. |
| `S3Drawer`, `S3DrawerHeader`, `S3DrawerBody`, `S3DrawerFooter` | Component | alpha.8 | Experimental | Available | Side-panel primitive; no product shell behavior. |
| `S3Tooltip`, `S3Popover` | Component | alpha.8 | Experimental | Available | Floating UI primitives. |
| `S3Banner`, `S3Toast`, `S3ToastAction`, `S3ToastViewport`, `S3OperationFeedback` | Component | alpha.8 | Experimental | Available | Local transient feedback only. |
| `S3ToastProvider` | Wrapper | alpha.8 | Experimental | Available | Placeholder local provider; no backend notification ownership. |

No exports are deprecated in `1.0.0-alpha.10`.

## Internal APIs

`src/components/*`, `src/utilities/*`, `components/platform-primitives.css`, `layout/platform-layout.css` and token internals are not public import paths for products. Use the package entrypoint and documented CSS entrypoints only.
