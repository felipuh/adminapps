# CSS Contract

## Public Entrypoints

Current local entrypoint:

```css
@import "../../../design-system/styles/platform.css";
```

Package entrypoint:

```css
@import "@smart3ai/design-system/styles/platform.css";
```

`@smart3ai/design-system/styles` is also exported for tools that honor package `exports`, but current Vite/PostCSS consumer builds should use the explicit CSS file path.

Token entrypoint:

```css
@import "@smart3ai/design-system/tokens";
```

## Import Order

Import `styles/platform.css` before product styles. Product styles may compose pages and product-specific experiences, but should not redefine platform typography, buttons, fields, badges, tables, overlays, focus rings, motion or foundational tokens.

`platform.css` imports tokens, primitive CSS and layout CSS. Consumers should not depend on the internal order of files below that entrypoint.

## Public Selectors

Public selectors include documented `s3-*` component classes, compatibility aliases listed in README and token selectors such as `html.dark`, `html.theme-dark` and `.s3-on-dark`.

Internal selectors inside component implementations are not guaranteed unless listed in component docs or `tests/public-api.test.mjs`.

## Themes

Dark mode is controlled by `html.dark` or `html.theme-dark`. `.s3-on-dark` is a public helper for components rendered on dark product-owned surfaces.

## Side Effects

The stylesheet intentionally defines platform-level typography, focus, primitive component styles, responsive protection, scrollbars, overlays and reduced-motion behavior.

## Reset

No global product reset is added beyond platform-safe defaults already present in `styles/platform.css` and imported files. Products remain responsible for app shell layout and page-specific resets.

## Compatibility

Consumers must not rely on undocumented internal class names, deep CSS paths or file order below `styles/platform.css`.
