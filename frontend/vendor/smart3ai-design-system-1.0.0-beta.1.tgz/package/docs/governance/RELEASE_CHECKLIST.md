# Release Checklist

Version: `1.0.0-alpha.10`

- [x] Version updated in `package.json`, README and changelog.
- [x] Changelog entry describes scope and known non-goals.
- [x] Public API inventory is current.
- [x] Contract tests pass.
- [x] Token validation passes.
- [x] Forbidden import validation passes.
- [x] Unit or source contract checks pass.
- [x] Lint/build command for the package passes.
- [x] `npm pack --dry-run` reviewed.
- [x] AdminApps build checked or deferral documented.
- [x] ISO Smart build checked or deferral documented.
- [x] ISO Smart MedSupplier build checked or deferral documented.
- [x] Landing build or TypeScript check completed or deferral documented.
- [ ] Consumer lint checked where relevant or deferral documented.
- [ ] Light mode reviewed.
- [ ] Dark mode reviewed.
- [ ] Responsive behavior reviewed.
- [ ] Keyboard behavior reviewed.
- [ ] Accessibility standard reviewed.
- [ ] Visual evidence captured for visual changes.
- [x] Package contents exclude secrets, logs, databases, temp files and product artifacts.
- [x] Secrets scan completed.
- [x] License and dependency review completed.
- [x] Migration notes updated when needed.
- [x] Rollback plan documented.
- [ ] Product Platform Owner approval recorded.
- [ ] Release Approver approval recorded.

Alpha 10 does not publish, tag, deploy or create a public release. Consumer lint remains deferred because the closure gate is packaged install plus smoke build compatibility, not product lint cleanup.
