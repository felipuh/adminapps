# Deprecation Policy

Deprecations protect consumers from silent breakage.

## Required Fields

Every deprecation must document:

- Component, token, CSS selector, entrypoint or prop affected.
- Version where deprecation starts.
- Replacement API.
- Migration guide.
- Known consumers.
- Planned removal version.
- User-visible warning or changelog note.
- Compatibility tests that keep the deprecated API alive until removal.

## Rules

- Do not remove a public API in the same minor line where it is deprecated.
- Do not remove a public API during alpha or beta without documenting consumer impact.
- Deprecated APIs remain in `docs/api/public-api.md` until removal.
- Removal requires Release Approver approval and affected Product Consumer Owner confirmation.
- Internal APIs may change without deprecation only when they are not consumed by products and are not listed as public.

## Removal Gate

Removal is allowed only when all known consumers have migrated or explicitly accepted the break, migration notes exist, contract tests are updated and rollback is documented.
