# Ownership

Ownership is role-based until named maintainers are approved.

## Roles

| Area | Primary role | Required review |
| --- | --- | --- |
| Design tokens | Design System Maintainer | Product Platform Owner, Accessibility Reviewer |
| React components | Design System Maintainer | Frontend Architecture Reviewer |
| Accessibility | Accessibility Reviewer | Design System Maintainer |
| Documentation | Design System Maintainer | Product Consumer Owner when consumer-facing |
| Releases | Release Approver | Product Platform Owner |
| Visual review | Product Platform Owner | Product Consumer Owner for affected products |
| Compatibility testing | Frontend Architecture Reviewer | Product Consumer Owner |
| Breaking changes | Release Approver | Product Platform Owner, affected Product Consumer Owner |

## Responsibilities

Product Platform Owner defines cross-product UX direction and approves platform-level scope.

Design System Maintainer owns package structure, component implementation, tokens, documentation and changelog quality.

Frontend Architecture Reviewer owns package boundaries, peer dependencies, import rules, build compatibility and consumer smoke strategy.

Accessibility Reviewer owns WCAG AA criteria, manual accessibility review and release blocking accessibility findings.

Product Consumer Owner owns validation in AdminApps, ISO Smart, ISO Smart MedSupplier or Landing and confirms product behavior remains unchanged.

Release Approver owns final readiness decisions, rollback expectations, release notes and breaking-change communication.

## Minimum Beta Approval Mechanism

Every Beta release proposal must identify:

- Proposer: opens the package change and prepares evidence.
- Reviewer: validates frontend architecture, package boundary, peer dependencies and quality gates.
- Approver: signs off release readiness and rollback.
- Consumer validator: confirms affected product behavior in AdminApps, ISO Smart, ISO Smart MedSupplier or Landing.

Minimum approval gates:

- Product Platform Owner approval for scope and release readiness.
- Technical frontend review for public API, package manifest, dependency and build behavior.
- At least one affected consumer validation for any consumer-facing change.
- Accessibility validation for changes affecting keyboard, focus, ARIA, contrast, motion, forms, overlays or tables.
- Green quality gates or explicit written deferral for non-blocking documentation-only checks.

API changes, release promotion, token changes, accessibility-sensitive changes and consumer-impacting changes cannot be self-approved.

## Proposed CODEOWNERS

```text
/design-system/ Product-Platform-Owner Design-System-Maintainer
/design-system/src/ Design-System-Maintainer Frontend-Architecture-Reviewer
/design-system/styles/ Design-System-Maintainer Accessibility-Reviewer
/design-system/tokens/ Design-System-Maintainer Product-Platform-Owner
/design-system/docs/governance/ Product-Platform-Owner Release-Approver
/design-system/tests/ Frontend-Architecture-Reviewer Design-System-Maintainer
```

This is a proposal only. Do not add repository-level CODEOWNERS until repository strategy is approved.
