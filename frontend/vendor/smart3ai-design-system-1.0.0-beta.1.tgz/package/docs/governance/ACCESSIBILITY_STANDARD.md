# Accessibility Standard

Smart3AI shared components target WCAG 2.2 AA.

## Requirements

- Keyboard users can reach, operate and leave interactive components.
- Focus is visible and not hidden by overlays or scrolling containers.
- Interactive controls have accessible names.
- ARIA is used only where it improves semantics.
- Color contrast meets AA in light and dark modes.
- Heading levels can fit consumer page structure.
- Reduced motion is respected through `prefers-reduced-motion`.
- Dialogs and drawers trap focus, restore focus and close with Escape when allowed.
- Tooltips are supplemental and do not hide required information.
- Forms expose labels, help text, error text and invalid state.
- Tables preserve semantic table structure and sorting state.
- Responsive layouts do not clip, overlap or hide required text.
- Screen readers receive status updates through appropriate live regions.

## Automatic Validation

Automatic checks include public API contract checks, CSS contract checks, token validation, package boundary validation and consumer smoke builds.

## Manual Validation

Manual checks are required for keyboard order, focus restoration, screen reader labels, dialog behavior, tooltip timing, visual contrast, responsive text fit and reduced-motion behavior.

## Release Blocking

Block release for inaccessible names, missing focus management in blocking overlays, keyboard traps, contrast failures on required text, broken form error association or table semantics regressions.
