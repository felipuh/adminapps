# Token Policy

Tokens are the public visual contract for Smart3AI products.

## Token Types

Global tokens describe raw foundations such as spacing, radius, typography, focus, shadow and timing.

Semantic tokens describe product meaning such as surface, text, border, action, danger, warning, success and info.

Component tokens are allowed when a shared component needs a stable value that should not be copied into products.

## Naming

All public CSS custom properties use `--s3-*`. Names should describe role and state, not one-off page usage.

## Dark Mode

Dark mode values must be defined through `html.dark`, `html.theme-dark` or documented dark surface selectors such as `.s3-on-dark`. Components must not require product-local dark overrides for core readability.

## Contrast

Text, focus and critical status tokens must satisfy WCAG AA contrast in supported themes. Any exception must be documented as decorative or disabled content.

## Hardcoded Values

Shared components should use tokens for recurring color, spacing, radius, shadow, transition and focus values. One-off structural values are acceptable only when they are internal and not likely to become product styling policy.

## Creating Tokens

Create a token when a value recurs across components or products, represents platform meaning, needs theme support or must remain stable for consumers.

Reuse a token when the visual role already exists, even if the current numeric value is not perfect.

## Deprecation

Token deprecations follow `DEPRECATION_POLICY.md`. Do not remove a token until consumers have migration guidance and compatibility evidence.

## Review

Token changes require Design System Maintainer review. Semantic token additions or removals require Product Platform Owner review. Contrast-sensitive tokens require Accessibility Reviewer review.
