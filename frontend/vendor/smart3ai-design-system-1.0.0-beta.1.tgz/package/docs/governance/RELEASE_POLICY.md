# Release Policy

The package remains private in Alpha 9. This policy defines readiness gates only; it does not authorize publication.

## Proposal

A Design System Maintainer proposes a release by updating version, changelog, public API docs, compatibility notes, migration notes and evidence.

## Review

Frontend Architecture Reviewer reviews package boundaries, exports, peer dependencies, build behavior and consumer smoke results.

Accessibility Reviewer reviews keyboard, focus, ARIA, contrast, forms, overlays, tables and reduced-motion behavior for affected components.

Product Consumer Owners review affected product smoke builds and visual impact.

## Approval

Release Approver approves only after required tests, docs and consumer checks pass or have explicit documented deferrals.

For Beta releases, approval requires Product Platform Owner sign-off, Frontend Architecture Reviewer sign-off, one affected Product Consumer Owner validation when consumers are affected and Accessibility Reviewer validation for accessibility-relevant changes.

## Required Checks

- `npm test`
- `npm run pack:dry-run`
- Consumer smoke builds when public APIs, CSS, tokens or peer dependencies change.
- Visual evidence for visual changes.
- Accessibility review for interaction changes.
- Dependency and license review before publication is authorized.
- `npm run verify:consumers` without `--legacy-peer-deps` before Beta promotion.
- Runtime smoke when package entrypoints, styles, React peers or overlay/form/table components change.

## Changelog

The changelog is maintained manually during alpha. Each release entry must separate compatible additions, fixes, governance changes, deprecations and known risks.

## Version Assignment

Use SemVer. During prerelease, alpha may make controlled API changes, beta should stabilize API shape, rc should accept only release-blocking fixes and stable should require migration notes for any future breaking change.

## Rollback

Rollback requires the last known compatible package version, consumer matrix state, affected entrypoints and migration notes. Do not revert unrelated product changes as part of package rollback.

## Breaking Changes

Breaking changes require explicit label, consumer impact, migration guide, removal timing, Product Platform Owner approval and affected Product Consumer Owner acknowledgement.

## Release Blockers

Block release for missing public API documentation, failed contract tests, broken consumer build, undocumented peer dependency changes, accessibility regressions, package contents leakage, secrets, PII or unresolved breaking-change approval.
