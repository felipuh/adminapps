# Package Manager Policy

Status: Proposed for Beta 1 readiness closure

## Decision

Use npm for the Smart3AI Design System and current consumers during Beta 1.

Do not migrate to pnpm or Yarn in this phase.

## Rationale

All current frontends use `package-lock.json`, npm scripts and Vite. Keeping npm avoids a package-manager migration while dependency resolution and private distribution are being stabilized.

## Version Guidance

Use the Node/npm versions already supported by the active product environments. Do not add restrictive `engines` until CI proves the supported version floor and ceiling.

## Lockfile Policy

Consumers must commit `package-lock.json`.

Registry adoption will require a deliberate lockfile update in each consumer when `@smart3ai/design-system` changes from local alias or tarball to private registry dependency. Do this in a planned consumer branch, not as an incidental build artifact.

## Clean Install

Beta validation must use:

- Empty temporary copy.
- No original `node_modules`.
- No original `dist`.
- Temporary npm cache.
- Normal `npm install` or `npm ci` according to the test goal.
- No `--legacy-peer-deps`.

Use `npm ci` when validating an existing lockfile unchanged. Use `npm install` when validating new dependency resolution from a package artifact or registry.

## Release Commands

Design System:

```bash
npm test
npm run pack:dry-run
npm pack
npm run verify:consumers
```

Consumers:

```bash
npm install
npm run lint
npm run build
```

Landing does not currently define a lint script; its build includes TypeScript validation.

