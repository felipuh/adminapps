# Smart3AI Component Library v1.0

This directory is the permanent product design platform for the Smart3AI ecosystem. Product applications define business workflows; shared tokens, React components, reusable CSS primitives, layout behavior, motion, accessibility and cross-product UX rules live here.

Current package version: `1.0.0-alpha.10`.

## Current Architecture

- `src/index.js`: public React API for shared Smart3AI components.
- `src/components/`: official shared component implementations.
- `tokens/smart3ai-tokens.css`: canonical color, spacing, radius, elevation, typography, motion and focus tokens.
- `components/platform-primitives.css`: shared primitive classes for buttons, fields, cards, badges, tables, modals and core states.
- `layout/platform-layout.css`: shared global page behavior, responsive text protection, focus treatment, scrollbars, dark mode surfaces and reduced-motion behavior.
- `styles/platform.css`: single import entrypoint for product frontends.
- `docs/architecture/ADR-0001-shared-react-package.md`: architecture decision record for the shared library strategy.
- `docs/architecture/ADR-0002-repository-and-distribution-strategy.md`: proposed repository and distribution strategy for Beta readiness.
- `docs/api/public-api.md`: Alpha 10 public API and entrypoint inventory.
- `docs/api/css-contract.md`: CSS import, theme and selector contract.
- `docs/compatibility/consumer-matrix.md`: current consumer compatibility matrix.
- `docs/compatibility/runtime-compatibility.md`: runtime and peer dependency compatibility.
- `docs/governance/`: ownership, release, deprecation, token and accessibility policies.

## Product Contract

Every Smart3AI product must import `design-system/styles/platform.css` before local product styles. Product code may define business screens, data, copy and workflows, but must not redefine foundational typography, spacing, surfaces, buttons, inputs, tables, cards, badges, modals, empty states, loading states, error states, focus rings or motion rules.

Shared React components must be imported from the public package entrypoint:

```jsx
import {
  S3Button,
  S3EmptyState,
  S3InlineAlert,
  S3LoadingState,
  S3PageLayout,
  S3PageContent,
  S3ContentSection,
  S3ActionBar,
  S3Breadcrumbs,
  S3BreadcrumbItem,
  S3Panel,
  S3Grid,
  S3PageHeader,
  S3StatusBadge,
  S3Dialog,
  S3DialogHeader,
  S3DialogTitle,
  S3DialogBody,
  S3DialogFooter,
  S3Drawer,
  S3Tooltip,
  S3Popover,
  S3Banner,
  S3Toast,
  S3ToastViewport,
  S3OperationFeedback,
  S3Table,
  S3TableBody,
  S3TableCell,
  S3TableContainer,
  S3TableHead,
  S3TableHeader,
  S3TableRow,
} from '@smart3ai/design-system';
```

Do not import from internal files such as `design-system/src/components/S3Button.jsx` in product code.

## Naming

React components use the `S3` prefix to avoid collisions with local product components and future third-party libraries. CSS classes use the existing `s3-*` convention.

## Mandatory UX Patterns

- Buttons use `btn-primary`, `btn-secondary`, `btn-danger`, `btn-success` or their `s3-button-*` aliases.
- Fields use `input-glass`, `input-styled`, `field-control` or `s3-field`.
- Repeated surfaces use `enterprise-card`, `enterprise-panel`, `glass-card` or `s3-card`.
- Status labels use `badge-success`, `badge-warning`, `badge-danger`, `badge-info` or `badge-neutral`.
- Data tables use `S3Table*` primitives for new shared migrations. Existing `table-glass` and `enterprise-table` product wrappers may remain until safely migrated.
- Page structure uses `S3PageLayout`, `S3PageContent`, `S3ContentSection`, `S3ActionBar`, `S3Breadcrumbs`, `S3Panel` and the layout primitives for new shared migrations.
- Blocking overlays use `S3Dialog` or `S3Drawer`; transient contextual layers use `S3Tooltip`, `S3Popover`, `S3Banner`, `S3Toast` and `S3OperationFeedback`.
- Empty, loading and error states use the platform state primitives or product components built on top of them.
- Dark mode must be controlled with `html.dark` or `html.theme-dark`.
- Motion must respect `prefers-reduced-motion`.

## Governance Rules

- Add a token before adding a hardcoded design value that must recur across products.
- Add a primitive only when it supports multiple current or expected products.
- Avoid duplicate components with the same job. Extend an existing primitive with a documented variant instead.
- Keep product-specific CSS limited to page composition and brand storytelling.
- New Smart3AI products should start by importing this platform stylesheet and reusing the existing primitives.
- Keep component APIs semantic and limited. Prefer `variant`, `size`, `loading`, `disabled`, `status`, `title`, `description`, `children`, and composition over arbitrary visual props.
- Shared components must not depend on product i18n instances, API clients, permissions, models, routes or business rules.
- Shared layout components must not render product shells, sidebars, topbars, route guards, permissions, session data or generated navigation.
- Shared overlay and feedback components must not fetch notifications, own permissions, navigate, subscribe to backend events, persist toasts or create a mandatory global overlay manager.

## Alpha 10 Beta Closure

Alpha 10 closes the Beta readiness pass for the existing package through packaged artifact verification. It does not publish the package, create a Git repository, create a tag, move files, deploy changes or expand the component catalog.

Run local package checks from this directory:

```bash
npm test
npm run pack:dry-run
```

Run consumer smoke checks only when intentionally validating all products:

```bash
npm run verify:consumers
```

Known current consumption remains source-based through Vite aliases in AdminApps, ISO Smart and ISO Smart MedSupplier, plus platform CSS imports in all four products. Alpha 10 additionally verifies isolated consumer builds from the packed tarball before any Beta 1 decision. Future package distribution requires human approval as described in ADR-0002.
