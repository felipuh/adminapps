import React, { forwardRef } from 'react';
import { classNames } from '../utilities/classNames.js';

function fieldStateClasses({ className, invalid, prefix, suffix }) {
  return classNames(
    's3-field',
    invalid && 's3-field-invalid',
    prefix && 's3-field-has-prefix',
    suffix && 's3-field-has-suffix',
    className,
  );
}

function AffixedControl({ children, prefix, suffix }) {
  if (!prefix && !suffix) return children;

  return (
    <span className="s3-field-affix">
      {prefix ? <span className="s3-field-affix__item" aria-hidden="true">{prefix}</span> : null}
      {children}
      {suffix ? <span className="s3-field-affix__item" aria-hidden="true">{suffix}</span> : null}
    </span>
  );
}

export const S3Input = forwardRef(function S3Input({
  className,
  invalid = false,
  prefix,
  suffix,
  type = 'text',
  ...props
}, ref) {
  return (
    <AffixedControl prefix={prefix} suffix={suffix}>
      <input
        ref={ref}
        className={fieldStateClasses({ className, invalid, prefix, suffix })}
        type={type}
        aria-invalid={invalid ? 'true' : props['aria-invalid']}
        {...props}
      />
    </AffixedControl>
  );
});

export const S3Textarea = forwardRef(function S3Textarea({
  className,
  invalid = false,
  resize = 'vertical',
  ...props
}, ref) {
  return (
    <textarea
      ref={ref}
      className={classNames('s3-field', 's3-textarea', `s3-textarea-resize-${resize}`, invalid && 's3-field-invalid', className)}
      aria-invalid={invalid ? 'true' : props['aria-invalid']}
      {...props}
    />
  );
});

export const S3Select = forwardRef(function S3Select({
  children,
  className,
  invalid = false,
  placeholder,
  ...props
}, ref) {
  return (
    <select
      ref={ref}
      className={classNames('s3-field', 's3-select', invalid && 's3-field-invalid', className)}
      aria-invalid={invalid ? 'true' : props['aria-invalid']}
      {...props}
    >
      {placeholder ? <option value="" disabled={props.required}>{placeholder}</option> : null}
      {children}
    </select>
  );
});

function ChoiceControl({
  children,
  className,
  helpText,
  invalid = false,
  label,
  type,
  ...props
}, ref) {
  const isSwitch = type === 'switch';
  const inputType = isSwitch ? 'checkbox' : type;

  return (
    <label className={classNames('s3-choice', isSwitch && 's3-switch', invalid && 's3-choice-invalid', className)}>
      <input
        ref={ref}
        type={inputType}
        role={isSwitch ? 'switch' : undefined}
        className="s3-choice__input"
        aria-invalid={invalid ? 'true' : props['aria-invalid']}
        {...props}
      />
      <span className="s3-choice__control" aria-hidden="true" />
      <span className="s3-choice__body">
        <span className="s3-choice__label">{label || children}</span>
        {helpText ? <span className="s3-choice__help">{helpText}</span> : null}
      </span>
    </label>
  );
}

export const S3Checkbox = forwardRef(function S3Checkbox(props, ref) {
  return ChoiceControl({ ...props, type: 'checkbox' }, ref);
});

export const S3Radio = forwardRef(function S3Radio(props, ref) {
  return ChoiceControl({ ...props, type: 'radio' }, ref);
});

export const S3Switch = forwardRef(function S3Switch(props, ref) {
  return ChoiceControl({ ...props, type: 'switch' }, ref);
});
