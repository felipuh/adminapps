import React from 'react';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, ChevronsUpDown } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';
import { S3Button } from './S3Button.jsx';
import { S3EmptyState } from './S3EmptyState.jsx';
import { S3InlineAlert } from './S3InlineAlert.jsx';
import { S3LoadingState } from './S3LoadingState.jsx';

const ALIGN_CLASS = {
  center: 's3-table-cell-center',
  end: 's3-table-cell-end',
  start: 's3-table-cell-start',
};

const DENSITY_CLASS = {
  compact: 's3-table-container-compact',
  comfortable: 's3-table-container-comfortable',
};

const SORT_ARIA = {
  ascending: 'ascending',
  descending: 'descending',
  none: 'none',
};

export const S3TableContainer = React.forwardRef(function S3TableContainer({
  children,
  className,
  density = 'comfortable',
  elevated = false,
  ...props
}, ref) {
  return (
    <div
      ref={ref}
      className={classNames(
        's3-table-container',
        DENSITY_CLASS[density] || DENSITY_CLASS.comfortable,
        elevated && 's3-table-container-elevated',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
});

export const S3Table = React.forwardRef(function S3Table({ children, className, ...props }, ref) {
  return (
    <table ref={ref} className={classNames('s3-table', className)} {...props}>
      {children}
    </table>
  );
});

export const S3TableHead = React.forwardRef(function S3TableHead({ children, className, ...props }, ref) {
  return (
    <thead ref={ref} className={classNames('s3-table-head', className)} {...props}>
      {children}
    </thead>
  );
});

export const S3TableBody = React.forwardRef(function S3TableBody({ children, className, ...props }, ref) {
  return (
    <tbody ref={ref} className={classNames('s3-table-body', className)} {...props}>
      {children}
    </tbody>
  );
});

export const S3TableFooter = React.forwardRef(function S3TableFooter({ children, className, ...props }, ref) {
  return (
    <tfoot ref={ref} className={classNames('s3-table-footer', className)} {...props}>
      {children}
    </tfoot>
  );
});

export const S3TableRow = React.forwardRef(function S3TableRow({ children, className, interactive = false, selected = false, ...props }, ref) {
  return (
    <tr
      ref={ref}
      className={classNames('s3-table-row', interactive && 's3-table-row-interactive', selected && 's3-table-row-selected', className)}
      aria-selected={selected ? 'true' : props['aria-selected']}
      {...props}
    >
      {children}
    </tr>
  );
});

export const S3TableHeader = React.forwardRef(function S3TableHeader({
  align = 'start',
  children,
  className,
  disabled = false,
  onSort,
  scope = 'col',
  sortDirection = 'none',
  sortLabel,
  sortable = false,
  truncate = false,
  ...props
}, ref) {
  const normalizedSort = SORT_ARIA[sortDirection] ? sortDirection : 'none';
  const canSort = sortable && typeof onSort === 'function';
  const SortIcon = normalizedSort === 'ascending' ? ArrowUp : normalizedSort === 'descending' ? ArrowDown : ChevronsUpDown;

  return (
    <th
      ref={ref}
      scope={scope}
      aria-sort={sortable ? SORT_ARIA[normalizedSort] : undefined}
      className={classNames(
        's3-table-header',
        ALIGN_CLASS[align] || ALIGN_CLASS.start,
        truncate && 's3-table-cell-truncate',
        sortable && 's3-table-header-sortable',
        className,
      )}
      {...props}
    >
      {canSort ? (
        <button
          type="button"
          className="s3-table-sort-button"
          onClick={onSort}
          disabled={disabled}
          aria-label={sortLabel}
        >
          <span className="s3-table-sort-button__content">{children}</span>
          <SortIcon className="s3-table-sort-button__icon" aria-hidden="true" />
        </button>
      ) : children}
    </th>
  );
});

export const S3TableCell = React.forwardRef(function S3TableCell({
  align = 'start',
  children,
  className,
  numeric = false,
  truncate = false,
  wrap = true,
  ...props
}, ref) {
  return (
    <td
      ref={ref}
      className={classNames(
        's3-table-cell',
        ALIGN_CLASS[align] || ALIGN_CLASS.start,
        numeric && 's3-table-cell-numeric',
        truncate && 's3-table-cell-truncate',
        !wrap && 's3-table-cell-nowrap',
        className,
      )}
      {...props}
    >
      {children}
    </td>
  );
});

export const S3TableCaption = React.forwardRef(function S3TableCaption({ children, className, ...props }, ref) {
  return (
    <caption ref={ref} className={classNames('s3-table-caption', className)} {...props}>
      {children}
    </caption>
  );
});

export function S3TableLoading({ className, colSpan, columnCount = 1, label }) {
  const resolvedColSpan = colSpan || columnCount;

  return (
    <tr className={classNames('s3-table-state-row', className)}>
      <td className="s3-table-state-cell" colSpan={resolvedColSpan}>
        <S3LoadingState variant="section" label={label} />
      </td>
    </tr>
  );
}

export function S3TableEmpty({ action, className, colSpan = 1, description, icon, title }) {
  return (
    <S3EmptyState
      action={action}
      className={classNames('s3-table-state', className)}
      colSpan={colSpan}
      description={description}
      icon={icon}
      title={title}
    />
  );
}

export function S3TableError({ action, className, colSpan = 1, description, title }) {
  return (
    <tr className={classNames('s3-table-state-row', className)}>
      <td className="s3-table-state-cell" colSpan={colSpan}>
        <S3InlineAlert
          className="s3-table-state"
          title={title}
          message={description}
          variant="danger"
        />
        {action ? <div className="s3-table-state-action">{action}</div> : null}
      </td>
    </tr>
  );
}

export const S3TableToolbar = React.forwardRef(function S3TableToolbar({ children, className, ...props }, ref) {
  return (
    <div ref={ref} className={classNames('s3-table-toolbar', className)} {...props}>
      {children}
    </div>
  );
});

export const S3TableActions = React.forwardRef(function S3TableActions({ children, className, ...props }, ref) {
  return (
    <div ref={ref} className={classNames('s3-table-actions', className)} {...props}>
      {children}
    </div>
  );
});

export function S3PaginationSummary({ className, children, page, pageCount, totalItems, label }) {
  const content = children || label || (totalItems === undefined
    ? `${page} / ${pageCount}`
    : `${totalItems} items`);

  return <p className={classNames('s3-pagination-summary', className)}>{content}</p>;
}

export function S3Pagination({
  className,
  disabled = false,
  loading = false,
  nextLabel = 'Next',
  onPageChange,
  page,
  pageCount,
  paginationLabel = 'Pagination',
  previousLabel = 'Previous',
}) {
  const isDisabled = disabled || loading;
  const canGoPrevious = !isDisabled && page > 1;
  const canGoNext = !isDisabled && page < pageCount;

  return (
    <nav className={classNames('s3-pagination', className)} aria-label={paginationLabel}>
      <S3Button
        type="button"
        variant="secondary"
        size="sm"
        icon={ChevronLeft}
        disabled={!canGoPrevious}
        onClick={() => onPageChange?.(page - 1)}
      >
        {previousLabel}
      </S3Button>
      <S3PaginationSummary page={page} pageCount={pageCount} />
      <S3Button
        type="button"
        variant="secondary"
        size="sm"
        endIcon={ChevronRight}
        disabled={!canGoNext}
        onClick={() => onPageChange?.(page + 1)}
      >
        {nextLabel}
      </S3Button>
    </nav>
  );
}
