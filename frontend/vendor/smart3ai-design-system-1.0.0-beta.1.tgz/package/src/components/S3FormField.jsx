import React, { Children, cloneElement, isValidElement, useId } from 'react';
import { classNames } from '../utilities/classNames.js';

const CONTROL_TYPES = new Set(['input', 'textarea', 'select']);

const mergeDescribedBy = (...ids) => ids.filter(Boolean).join(' ') || undefined;

function isFormControl(element) {
  return isValidElement(element) && (
    typeof element.type === 'string' && CONTROL_TYPES.has(element.type)
    || typeof element.type === 'function'
  );
}

export function S3FieldLabel({ children, className, htmlFor, required = false, ...props }) {
  return (
    <label className={classNames('s3-field-label', className)} htmlFor={htmlFor} {...props}>
      <span>{children}</span>
      {required ? <span className="s3-field-label__required" aria-hidden="true">*</span> : null}
    </label>
  );
}

export function S3FieldHelp({ children, className, id, ...props }) {
  if (!children) return null;

  return (
    <p className={classNames('s3-field-help', className)} id={id} {...props}>
      {children}
    </p>
  );
}

export function S3FieldError({ children, className, id, role = 'alert', ...props }) {
  if (!children) return null;

  return (
    <p className={classNames('s3-field-error', className)} id={id} role={role} aria-live="polite" {...props}>
      {children}
    </p>
  );
}

export function S3FormField({
  children,
  className,
  controlId,
  disabled = false,
  error,
  helpText,
  id,
  label,
  readOnly = false,
  required = false,
  ...props
}) {
  const generatedId = useId();
  const fieldId = id || `s3-field-${generatedId}`;
  const inputId = controlId || `${fieldId}-control`;
  const helpId = helpText ? `${fieldId}-help` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  const describedBy = mergeDescribedBy(helpId, errorId);

  const enhancedChildren = Children.map(children, (child) => {
    if (!isFormControl(child)) return child;

    return cloneElement(child, {
      id: child.props.id || inputId,
      required: child.props.required ?? required,
      disabled: child.props.disabled ?? disabled,
      readOnly: child.props.readOnly ?? readOnly,
      invalid: child.props.invalid ?? Boolean(error),
      'aria-describedby': mergeDescribedBy(child.props['aria-describedby'], describedBy),
      'aria-invalid': child.props['aria-invalid'] ?? (error ? 'true' : undefined),
    });
  });

  return (
    <div
      className={classNames(
        's3-form-field',
        disabled && 's3-form-field-disabled',
        readOnly && 's3-form-field-readonly',
        error && 's3-form-field-invalid',
        className,
      )}
      {...props}
    >
      {label ? <S3FieldLabel htmlFor={inputId} required={required}>{label}</S3FieldLabel> : null}
      {enhancedChildren}
      <S3FieldHelp id={helpId}>{helpText}</S3FieldHelp>
      <S3FieldError id={errorId}>{error}</S3FieldError>
    </div>
  );
}
