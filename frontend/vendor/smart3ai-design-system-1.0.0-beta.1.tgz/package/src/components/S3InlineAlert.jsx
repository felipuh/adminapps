import React from 'react';
import { AlertCircle, CheckCircle2, Info, TriangleAlert, X } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';

const VARIANT_ICON = {
  danger: AlertCircle,
  error: AlertCircle,
  info: Info,
  success: CheckCircle2,
  warning: TriangleAlert,
};

export function S3InlineAlert({
  ariaLive = 'polite',
  children,
  className,
  dismissLabel = 'Dismiss',
  message,
  onClose,
  title,
  variant = 'danger',
}) {
  const Icon = VARIANT_ICON[variant] || AlertCircle;
  const normalizedVariant = variant === 'error' ? 'danger' : variant;
  const content = children || message;

  if (!content && !title) return null;

  return (
    <div
      className={classNames('s3-inline-alert', `s3-inline-alert-${normalizedVariant}`, className)}
      role={normalizedVariant === 'danger' ? 'alert' : 'status'}
      aria-live={ariaLive}
    >
      <div className="s3-inline-alert__content">
        <span className="s3-inline-alert__icon">
          <Icon className="s3-state-icon__svg" aria-hidden="true" />
        </span>
        <div>
          {title ? <p className="s3-inline-alert__title">{title}</p> : null}
          {content ? <p className="s3-inline-alert__message">{content}</p> : null}
        </div>
      </div>
      {onClose ? (
        <button
          type="button"
          className="s3-inline-alert__close"
          onClick={onClose}
          aria-label={dismissLabel}
        >
          <X className="s3-state-icon__svg" aria-hidden="true" />
        </button>
      ) : null}
    </div>
  );
}

export const S3ErrorState = S3InlineAlert;
