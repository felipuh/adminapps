import React from 'react';
import { Loader2 } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';

const VARIANT_CLASS = {
  button: 's3-loading-state-inline',
  inline: 's3-loading-state-inline',
  overlay: 's3-loading-state-overlay',
  page: 's3-loading-state-page',
  section: 's3-loading-state-section',
  skeleton: 's3-loading-state-section',
};

export function S3LoadingState({
  ariaBusy = true,
  ariaLive = 'polite',
  children,
  className,
  label = 'Loading',
  size = 'md',
  variant = 'section',
}) {
  const normalizedVariant = VARIANT_CLASS[variant] ? variant : 'section';

  return (
    <div
      className={classNames('s3-loading-state', VARIANT_CLASS[normalizedVariant], `s3-loading-state-${size}`, className)}
      role="status"
      aria-live={ariaLive}
      aria-busy={ariaBusy}
    >
      <Loader2 className="s3-loading-state__spinner" aria-hidden="true" />
      {label ? <span>{label}</span> : null}
      {children}
    </div>
  );
}
