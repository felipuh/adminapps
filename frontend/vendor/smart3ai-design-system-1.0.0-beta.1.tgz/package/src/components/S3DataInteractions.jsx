import React, { useId } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';
import { S3Button, S3IconButton } from './S3Button.jsx';
import { S3Checkbox, S3Select } from './S3FormControls.jsx';
import { S3FieldLabel } from './S3FormField.jsx';

export const S3DataToolbar = React.forwardRef(function S3DataToolbar({ children, className, ...props }, ref) {
  return (
    <div ref={ref} className={classNames('s3-data-toolbar', className)} {...props}>
      {children}
    </div>
  );
});

export const S3SearchInput = React.forwardRef(function S3SearchInput({
  active = false,
  className,
  clearLabel = 'Clear search',
  disabled = false,
  id,
  label,
  loading = false,
  onChange,
  onClear,
  onKeyDown,
  placeholder,
  value = '',
  ...props
}, ref) {
  const generatedId = useId();
  const inputId = id || generatedId;
  const hasValue = value !== undefined && value !== null && String(value).length > 0;

  const handleChange = (event) => {
    onChange?.(event.target.value, event);
  };

  const handleClear = () => {
    if (disabled) return;
    if (typeof onClear === 'function') {
      onClear();
      return;
    }
    onChange?.('');
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Escape' && hasValue) {
      handleClear();
    }
    onKeyDown?.(event);
  };

  return (
    <div className={classNames('s3-search-input', (active || hasValue) && 's3-search-input-active', className)}>
      {label ? <S3FieldLabel htmlFor={inputId}>{label}</S3FieldLabel> : null}
      <span className="s3-search-input__control">
        <Search className="s3-search-input__icon" aria-hidden="true" />
        <input
          ref={ref}
          id={inputId}
          className="s3-field s3-search-input__field"
          type="search"
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          aria-busy={loading ? 'true' : undefined}
          {...props}
        />
        {hasValue ? (
          <S3IconButton
            className="s3-search-input__clear"
            ariaLabel={clearLabel}
            icon={X}
            size="sm"
            variant="ghost"
            disabled={disabled}
            onClick={handleClear}
          />
        ) : null}
      </span>
    </div>
  );
});

export const S3FilterBar = React.forwardRef(function S3FilterBar({ children, className, label, ...props }, ref) {
  return (
    <div ref={ref} className={classNames('s3-filter-bar', className)} aria-label={label} {...props}>
      {children}
    </div>
  );
});

export const S3FilterGroup = React.forwardRef(function S3FilterGroup({ children, className, label, ...props }, ref) {
  return (
    <fieldset ref={ref} className={classNames('s3-filter-group', className)} {...props}>
      {label ? <legend className="s3-filter-group__label">{label}</legend> : null}
      <div className="s3-filter-group__content">{children}</div>
    </fieldset>
  );
});

export const S3FilterSelect = React.forwardRef(function S3FilterSelect({
  children,
  className,
  label,
  id,
  onChange,
  ...props
}, ref) {
  const generatedId = useId();
  const selectId = id || generatedId;
  const handleChange = (event) => {
    onChange?.(event.target.value, event);
  };

  return (
    <div className={classNames('s3-filter-select', className)}>
      {label ? <S3FieldLabel htmlFor={selectId}>{label}</S3FieldLabel> : null}
      <S3Select ref={ref} id={selectId} onChange={handleChange} {...props}>
        {children}
      </S3Select>
    </div>
  );
});

export const S3FilterCheckbox = React.forwardRef(function S3FilterCheckbox(props, ref) {
  return <S3Checkbox ref={ref} className={classNames('s3-filter-checkbox', props.className)} {...props} />;
});

export const S3ActiveFilters = React.forwardRef(function S3ActiveFilters({
  children,
  className,
  label,
  ...props
}, ref) {
  return (
    <div ref={ref} className={classNames('s3-active-filters', className)} {...props}>
      {label ? (
        <span className="s3-active-filters__label">
          <SlidersHorizontal aria-hidden="true" />
          {label}
        </span>
      ) : null}
      <div className="s3-active-filters__chips">{children}</div>
    </div>
  );
});

export function S3FilterChip({
  className,
  label,
  onRemove,
  removeLabel,
  value,
  ...props
}) {
  return (
    <span className={classNames('s3-filter-chip', className)} {...props}>
      <span className="s3-filter-chip__content">
        {label ? <span className="s3-filter-chip__label">{label}</span> : null}
        <span className="s3-filter-chip__value">{value}</span>
      </span>
      {onRemove ? (
        <button type="button" className="s3-filter-chip__remove" onClick={onRemove} aria-label={removeLabel}>
          <X aria-hidden="true" />
        </button>
      ) : null}
    </span>
  );
}

export function S3ClearFiltersButton({
  children,
  clearLabel = 'Clear filters',
  ...props
}) {
  return (
    <S3Button type="button" variant="ghost" size="sm" {...props}>
      {children || clearLabel}
    </S3Button>
  );
}

export function S3ResultsSummary({
  children,
  className,
  label,
  loading = false,
  ...props
}) {
  return (
    <p className={classNames('s3-results-summary', className)} aria-live="polite" aria-busy={loading ? 'true' : undefined} {...props}>
      {children || label}
    </p>
  );
}

export function S3FilteredResultsNotice({ children, className, ...props }) {
  return (
    <div className={classNames('s3-filtered-results-notice', className)} role="status" {...props}>
      {children}
    </div>
  );
}

export function S3SelectionCheckbox({
  ariaLabel,
  className,
  label,
  ...props
}) {
  return (
    <S3Checkbox
      className={classNames('s3-selection-checkbox', className)}
      label={label || ariaLabel}
      aria-label={ariaLabel}
      {...props}
    />
  );
}

export const S3SelectionCell = React.forwardRef(function S3SelectionCell({ children, className, ...props }, ref) {
  return (
    <td ref={ref} className={classNames('s3-table-cell', 's3-selection-cell', className)} {...props}>
      {children}
    </td>
  );
});

export function S3SelectionSummary({ children, className, count, label, ...props }) {
  return (
    <p className={classNames('s3-selection-summary', className)} aria-live="polite" {...props}>
      {children || label || count}
    </p>
  );
}

export const S3BulkActionsBar = React.forwardRef(function S3BulkActionsBar({
  children,
  className,
  clearLabel = 'Clear selection',
  count,
  disabled = false,
  loading = false,
  onClear,
  summary,
  ...props
}, ref) {
  return (
    <div ref={ref} className={classNames('s3-bulk-actions-bar', className)} aria-busy={loading ? 'true' : undefined} {...props}>
      <S3SelectionSummary count={count} label={summary} />
      <div className="s3-bulk-actions-bar__actions">{children}</div>
      {onClear ? (
        <S3Button type="button" variant="ghost" size="sm" disabled={disabled || loading} onClick={onClear}>
          {clearLabel}
        </S3Button>
      ) : null}
    </div>
  );
});
