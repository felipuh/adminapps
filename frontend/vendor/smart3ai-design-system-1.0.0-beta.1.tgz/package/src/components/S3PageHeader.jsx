import React from 'react';
import { classNames } from '../utilities/classNames.js';
import { S3Button } from './S3Button.jsx';

export function S3PageHeader({
  action,
  actionDisabled = false,
  actionLabel,
  actions,
  className,
  description,
  eyebrow = 'Smart3AI',
  onAction,
  subtitle,
  title,
}) {
  const resolvedDescription = description || subtitle;
  const resolvedAction = actions || action || (actionLabel && onAction ? (
    <S3Button onClick={onAction} disabled={actionDisabled}>
      {actionLabel}
    </S3Button>
  ) : null);

  return (
    <header className={classNames('s3-page-header', className)}>
      <div className="s3-page-header__body">
        <div className="s3-page-header__copy">
          {eyebrow ? <p className="s3-page-header__eyebrow">{eyebrow}</p> : null}
          <h1 className="s3-page-header__title">{title}</h1>
          {resolvedDescription ? <p className="s3-page-header__subtitle">{resolvedDescription}</p> : null}
        </div>
        {resolvedAction ? <div className="s3-page-header__actions">{resolvedAction}</div> : null}
      </div>
    </header>
  );
}
