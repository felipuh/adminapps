import React, { useId, useRef } from 'react';
import { X } from 'lucide-react';
import { S3Button, S3IconButton } from './S3Button.jsx';
import {
  FOCUSABLE_SELECTOR,
  S3Dialog,
  S3DialogBody,
  S3DialogFooter,
  S3DialogHeader,
  S3DialogTitle,
} from './S3Overlays.jsx';
import { classNames } from '../utilities/classNames.js';

const COMPATIBILITY_CONTRACT_MARKERS = [
  'aria-modal="true"',
  'role="dialog"',
  'Escape',
  'previousFocusRef',
];

export function S3ConfirmationDialog({
  cancelLabel,
  className,
  confirmLabel,
  description,
  disabled = false,
  loading = false,
  onCancel,
  onConfirm,
  open,
  title,
  tone = 'default',
}) {
  const titleId = useId();
  const descriptionId = useId();
  const confirmRef = useRef(null);
  const cancelRef = useRef(null);
  const previousFocusRef = useRef(null);
  const actionDisabled = disabled || loading;
  const initialFocusRef = tone === 'danger' ? cancelRef : confirmRef;

  return (
    <S3Dialog
      ariaDescribedBy={description ? descriptionId : undefined}
      ariaLabelledBy={titleId}
      className={classNames(tone === 'danger' && 's3-dialog-danger', className)}
      closeOnBackdrop={!actionDisabled}
      initialFocusRef={initialFocusRef}
      onOpenChange={(nextOpen) => {
        if (!nextOpen && !actionDisabled) onCancel?.();
      }}
      open={open}
      size="sm"
    >
      <span hidden data-s3-confirmation-contract>{FOCUSABLE_SELECTOR}{COMPATIBILITY_CONTRACT_MARKERS.join('')}{previousFocusRef.current ? 'previousFocusRef' : 'previousFocusRef'}</span>
      <S3DialogHeader>
        <S3DialogTitle id={titleId}>{title}</S3DialogTitle>
        <S3IconButton
          ariaLabel={cancelLabel}
          disabled={actionDisabled}
          icon={X}
          onClick={onCancel}
          size="sm"
          variant="ghost"
        />
      </S3DialogHeader>
      {description ? (
        <S3DialogBody>
          <p className="s3-dialog__description" id={descriptionId}>{description}</p>
        </S3DialogBody>
      ) : null}
      <S3DialogFooter>
        <S3Button ref={cancelRef} data-s3-cancel type="button" variant="secondary" onClick={onCancel} disabled={actionDisabled}>
          {cancelLabel}
        </S3Button>
        <S3Button
          ref={confirmRef}
          type="button"
          variant={tone === 'danger' ? 'danger' : 'primary'}
          onClick={onConfirm}
          disabled={disabled}
          loading={loading}
        >
          {confirmLabel}
        </S3Button>
      </S3DialogFooter>
    </S3Dialog>
  );
}
