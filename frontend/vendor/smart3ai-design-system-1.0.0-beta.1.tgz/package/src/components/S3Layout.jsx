import React from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';

const PAGE_SIZE_CLASS = {
  narrow: 's3-page-layout-narrow',
  default: 's3-page-layout-default',
  wide: 's3-page-layout-wide',
  full: 's3-page-layout-full',
};

const GAP_CLASS = {
  xs: 's3-gap-xs',
  sm: 's3-gap-sm',
  md: 's3-gap-md',
  lg: 's3-gap-lg',
  xl: 's3-gap-xl',
};

const SURFACE_VARIANT_CLASS = {
  default: 's3-surface-default',
  elevated: 's3-surface-elevated',
  outlined: 's3-surface-outlined',
  muted: 's3-surface-muted',
};

const ALIGN_CLASS = {
  start: 's3-align-start',
  center: 's3-align-center',
  end: 's3-align-end',
  stretch: 's3-align-stretch',
};

const JUSTIFY_CLASS = {
  start: 's3-justify-start',
  center: 's3-justify-center',
  end: 's3-justify-end',
  between: 's3-justify-between',
};

const HEADING_LEVELS = new Set([1, 2, 3, 4, 5, 6]);

function Heading({ level = 2, className, children, ...props }) {
  const resolvedLevel = HEADING_LEVELS.has(level) ? level : 2;
  const Component = `h${resolvedLevel}`;

  return (
    <Component className={className} {...props}>
      {children}
    </Component>
  );
}

export const S3PageLayout = React.forwardRef(function S3PageLayout({
  as: Component = 'main',
  children,
  className,
  size = 'default',
  ...props
}, ref) {
  return (
    <Component
      ref={ref}
      className={classNames('s3-page-layout', PAGE_SIZE_CLASS[size], className)}
      {...props}
    >
      {children}
    </Component>
  );
});

export const S3PageContent = React.forwardRef(function S3PageContent({
  as: Component = 'div',
  children,
  className,
  gap = 'lg',
  ...props
}, ref) {
  return (
    <Component ref={ref} className={classNames('s3-page-content', GAP_CLASS[gap], className)} {...props}>
      {children}
    </Component>
  );
});

export const S3PageSection = React.forwardRef(function S3PageSection({
  as: Component = 'section',
  children,
  className,
  ...props
}, ref) {
  return (
    <Component ref={ref} className={classNames('s3-page-section', className)} {...props}>
      {children}
    </Component>
  );
});

export const S3SectionHeader = React.forwardRef(function S3SectionHeader({
  actions,
  badge,
  className,
  description,
  headingLevel = 2,
  id,
  title,
  ...props
}, ref) {
  return (
    <header ref={ref} className={classNames('s3-section-header', className)} {...props}>
      <div className="s3-section-header__copy">
        <div className="s3-section-header__title-row">
          {title ? (
            <Heading id={id} level={headingLevel} className="s3-section-header__title">
              {title}
            </Heading>
          ) : null}
          {badge ? <span className="s3-section-header__badge">{badge}</span> : null}
        </div>
        {description ? <p className="s3-section-header__description">{description}</p> : null}
      </div>
      {actions ? <div className="s3-section-header__actions">{actions}</div> : null}
    </header>
  );
});

export const S3ContentSection = React.forwardRef(function S3ContentSection({
  actions,
  children,
  className,
  description,
  headingLevel = 2,
  id,
  title,
  ...props
}, ref) {
  const generatedId = React.useId();
  const headingId = id || (title ? `s3-content-section-${generatedId}` : props['aria-labelledby']);

  return (
    <section
      ref={ref}
      className={classNames('s3-content-section', className)}
      aria-labelledby={headingId || undefined}
      {...props}
    >
      {(title || description || actions) ? (
        <S3SectionHeader
          id={headingId}
          title={title}
          description={description}
          actions={actions}
          headingLevel={headingLevel}
        />
      ) : null}
      <div className="s3-content-section__body">{children}</div>
    </section>
  );
});

export const S3ActionBar = React.forwardRef(function S3ActionBar({
  align = 'center',
  children,
  className,
  gap = 'sm',
  justify = 'end',
  sticky = false,
  wrap = true,
  ...props
}, ref) {
  return (
    <div
      ref={ref}
      className={classNames(
        's3-action-bar',
        GAP_CLASS[gap],
        ALIGN_CLASS[align],
        JUSTIFY_CLASS[justify],
        wrap && 's3-action-bar-wrap',
        sticky && 's3-action-bar-sticky',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
});

export const S3PageActions = S3ActionBar;

export const S3Breadcrumbs = React.forwardRef(function S3Breadcrumbs({
  ariaLabel = 'Breadcrumb',
  children,
  className,
  separator,
  ...props
}, ref) {
  const items = React.Children.toArray(children).filter(Boolean);

  return (
    <nav ref={ref} aria-label={ariaLabel} className={classNames('s3-breadcrumbs', className)} {...props}>
      <ol className="s3-breadcrumbs__list">
        {items.map((child, index) => (
          <li className="s3-breadcrumbs__list-item" key={child.key || index}>
            {child}
            {index < items.length - 1 ? (
              <span className="s3-breadcrumbs__separator" aria-hidden="true">
                {separator || <ChevronRight />}
              </span>
            ) : null}
          </li>
        ))}
      </ol>
    </nav>
  );
});

export const S3BreadcrumbItem = React.forwardRef(function S3BreadcrumbItem({
  as,
  children,
  className,
  current = false,
  href,
  ...props
}, ref) {
  const Component = as || (href && !current ? 'a' : 'span');

  return (
    <Component
      ref={ref}
      className={classNames('s3-breadcrumb-item', current && 's3-breadcrumb-item-current', className)}
      href={Component === 'a' ? href : undefined}
      aria-current={current ? 'page' : undefined}
      {...props}
    >
      {children}
    </Component>
  );
});

export const S3BackLink = React.forwardRef(function S3BackLink({
  as,
  children,
  className,
  href,
  icon: Icon = ArrowLeft,
  type = 'button',
  ...props
}, ref) {
  const Component = as || (href ? 'a' : 'button');

  return (
    <Component
      ref={ref}
      className={classNames('s3-back-link', className)}
      href={Component === 'a' ? href : undefined}
      type={Component === 'button' ? type : undefined}
      {...props}
    >
      {Icon ? <Icon className="s3-back-link__icon" aria-hidden="true" /> : null}
      <span>{children}</span>
    </Component>
  );
});

export const S3Surface = React.forwardRef(function S3Surface({
  as: Component = 'div',
  children,
  className,
  padding = 'md',
  variant = 'default',
  ...props
}, ref) {
  return (
    <Component
      ref={ref}
      className={classNames('s3-surface', SURFACE_VARIANT_CLASS[variant], `s3-pad-${padding}`, className)}
      {...props}
    >
      {children}
    </Component>
  );
});

export const S3Panel = React.forwardRef(function S3Panel({
  actions,
  bodyClassName,
  children,
  className,
  description,
  footer,
  headingLevel = 2,
  title,
  variant = 'default',
  ...props
}, ref) {
  return (
    <S3Surface ref={ref} className={classNames('s3-panel', className)} variant={variant} padding="none" {...props}>
      {(title || description || actions) ? (
        <div className="s3-panel__header">
          <S3SectionHeader title={title} description={description} actions={actions} headingLevel={headingLevel} />
        </div>
      ) : null}
      <div className={classNames('s3-panel__body', bodyClassName)}>{children}</div>
      {footer ? <div className="s3-panel__footer">{footer}</div> : null}
    </S3Surface>
  );
});

export const S3Stack = React.forwardRef(function S3Stack({
  as: Component = 'div',
  align = 'stretch',
  children,
  className,
  gap = 'md',
  ...props
}, ref) {
  return (
    <Component ref={ref} className={classNames('s3-stack', GAP_CLASS[gap], ALIGN_CLASS[align], className)} {...props}>
      {children}
    </Component>
  );
});

export const S3Inline = React.forwardRef(function S3Inline({
  as: Component = 'div',
  align = 'center',
  children,
  className,
  gap = 'sm',
  justify = 'start',
  wrap = true,
  ...props
}, ref) {
  return (
    <Component
      ref={ref}
      className={classNames('s3-inline', GAP_CLASS[gap], ALIGN_CLASS[align], JUSTIFY_CLASS[justify], wrap && 's3-inline-wrap', className)}
      {...props}
    >
      {children}
    </Component>
  );
});

export const S3Grid = React.forwardRef(function S3Grid({
  as: Component = 'div',
  children,
  className,
  gap = 'md',
  min = '16rem',
  style,
  ...props
}, ref) {
  return (
    <Component
      ref={ref}
      className={classNames('s3-grid', GAP_CLASS[gap], className)}
      style={{ '--s3-grid-min': min, ...style }}
      {...props}
    >
      {children}
    </Component>
  );
});
