import React, { useEffect, useId, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, CheckCircle2, Info, Loader2, TriangleAlert, X } from 'lucide-react';
import { S3Button, S3IconButton } from './S3Button.jsx';
import { classNames } from '../utilities/classNames.js';

export const FOCUSABLE_SELECTOR = [
  'button:not([disabled])',
  '[href]',
  'input:not([disabled])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

const toneIcons = {
  danger: AlertCircle,
  error: AlertCircle,
  info: Info,
  success: CheckCircle2,
  warning: TriangleAlert,
};

const toastDurations = {
  short: 3000,
  default: 5000,
  long: 8000,
  persistent: null,
};

let scrollLockCount = 0;
let previousBodyOverflow = '';
let previousBodyPaddingRight = '';

function getOwnerDocument(container) {
  return container?.ownerDocument || (typeof document !== 'undefined' ? document : null);
}

function lockScroll(ownerDocument) {
  if (!ownerDocument) return () => {};
  const body = ownerDocument.body;
  if (scrollLockCount === 0) {
    previousBodyOverflow = body.style.overflow;
    previousBodyPaddingRight = body.style.paddingRight;
    const scrollbarWidth = window.innerWidth - ownerDocument.documentElement.clientWidth;
    body.style.overflow = 'hidden';
    if (scrollbarWidth > 0) body.style.paddingRight = `${scrollbarWidth}px`;
  }
  scrollLockCount += 1;
  return () => {
    scrollLockCount = Math.max(0, scrollLockCount - 1);
    if (scrollLockCount === 0) {
      body.style.overflow = previousBodyOverflow;
      body.style.paddingRight = previousBodyPaddingRight;
    }
  };
}

function usePortalContainer(container) {
  const [portalContainer, setPortalContainer] = useState(null);

  useEffect(() => {
    if (container) {
      setPortalContainer(container);
      return undefined;
    }
    if (typeof document === 'undefined') return undefined;

    const node = document.createElement('div');
    node.setAttribute('data-s3-portal', '');
    document.body.appendChild(node);
    setPortalContainer(node);
    return () => {
      node.remove();
    };
  }, [container]);

  return portalContainer;
}

function useOverlayBehavior({ contentRef, initialFocusRef, onDismiss, open, restoreFocus = true, trapFocus = true }) {
  const previousFocusRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const ownerDocument = getOwnerDocument(contentRef.current);
    if (!ownerDocument) return undefined;

    previousFocusRef.current = ownerDocument.activeElement;
    const releaseScroll = lockScroll(ownerDocument);
    const focusTarget = initialFocusRef?.current || contentRef.current?.querySelector(FOCUSABLE_SELECTOR) || contentRef.current;
    focusTarget?.focus?.();

    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onDismiss?.(event);
        return;
      }

      if (!trapFocus || event.key !== 'Tab') return;
      const focusable = Array.from(contentRef.current?.querySelectorAll(FOCUSABLE_SELECTOR) || []);
      if (focusable.length === 0) {
        event.preventDefault();
        contentRef.current?.focus?.();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && ownerDocument.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && ownerDocument.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    ownerDocument.addEventListener('keydown', handleKeyDown);
    return () => {
      ownerDocument.removeEventListener('keydown', handleKeyDown);
      releaseScroll();
      if (restoreFocus) previousFocusRef.current?.focus?.();
    };
  }, [contentRef, initialFocusRef, onDismiss, open, restoreFocus, trapFocus]);
}

function S3Portal({ children, container }) {
  const portalContainer = usePortalContainer(container);
  if (!portalContainer) return null;
  return createPortal(children, portalContainer);
}

export function S3Dialog({
  ariaDescribedBy,
  ariaLabel,
  ariaLabelledBy,
  children,
  className,
  closeOnBackdrop = true,
  container,
  initialFocusRef,
  onOpenChange,
  open,
  size = 'md',
}) {
  const contentRef = useRef(null);
  const requestClose = (event) => onOpenChange?.(false, event);
  useOverlayBehavior({ contentRef, initialFocusRef, onDismiss: requestClose, open });

  if (!open) return null;

  return (
    <S3Portal container={container}>
      <div
        className="s3-overlay s3-dialog-backdrop"
        data-s3-layer="modal"
        onMouseDown={(event) => {
          if (closeOnBackdrop && event.target === event.currentTarget) requestClose(event);
        }}
      >
        <div
          ref={contentRef}
          aria-describedby={ariaDescribedBy}
          aria-label={ariaLabel}
          aria-labelledby={ariaLabelledBy}
          aria-modal="true"
          className={classNames('s3-dialog', `s3-dialog-${size}`, className)}
          role="dialog"
          tabIndex={-1}
        >
          {children}
        </div>
      </div>
    </S3Portal>
  );
}

export function S3DialogHeader({ children, className }) {
  return <div className={classNames('s3-dialog__header', className)}>{children}</div>;
}

export function S3DialogTitle({ as: Component = 'h2', children, className, id }) {
  return <Component className={classNames('s3-dialog__title', className)} id={id}>{children}</Component>;
}

export function S3DialogDescription({ children, className, id }) {
  return <p className={classNames('s3-dialog__description', className)} id={id}>{children}</p>;
}

export function S3DialogBody({ children, className }) {
  return <div className={classNames('s3-dialog__body', className)}>{children}</div>;
}

export function S3DialogFooter({ children, className }) {
  return <div className={classNames('s3-dialog__footer', className)}>{children}</div>;
}

export function S3DialogClose({ ariaLabel = 'Close', children, onClick, ...props }) {
  if (children) {
    return <S3Button type="button" variant="secondary" onClick={onClick} {...props}>{children}</S3Button>;
  }
  return <S3IconButton ariaLabel={ariaLabel} icon={X} onClick={onClick} size="sm" variant="ghost" {...props} />;
}

export function S3Drawer({
  ariaDescribedBy,
  ariaLabel,
  ariaLabelledBy,
  children,
  className,
  closeOnBackdrop = true,
  container,
  initialFocusRef,
  onOpenChange,
  open,
  side = 'end',
}) {
  const contentRef = useRef(null);
  const requestClose = (event) => onOpenChange?.(false, event);
  useOverlayBehavior({ contentRef, initialFocusRef, onDismiss: requestClose, open });
  if (!open) return null;

  return (
    <S3Portal container={container}>
      <div
        className="s3-overlay s3-drawer-backdrop"
        data-s3-layer="drawer"
        onMouseDown={(event) => {
          if (closeOnBackdrop && event.target === event.currentTarget) requestClose(event);
        }}
      >
        <aside
          ref={contentRef}
          aria-describedby={ariaDescribedBy}
          aria-label={ariaLabel}
          aria-labelledby={ariaLabelledBy}
          aria-modal="true"
          className={classNames('s3-drawer', `s3-drawer-${side}`, className)}
          role="dialog"
          tabIndex={-1}
        >
          {children}
        </aside>
      </div>
    </S3Portal>
  );
}

export const S3DrawerHeader = ({ children, className }) => <div className={classNames('s3-drawer__header', className)}>{children}</div>;
export const S3DrawerBody = ({ children, className }) => <div className={classNames('s3-drawer__body', className)}>{children}</div>;
export const S3DrawerFooter = ({ children, className }) => <div className={classNames('s3-drawer__footer', className)}>{children}</div>;

export function S3Tooltip({ children, content, id, placement = 'top' }) {
  const generatedId = useId();
  const tooltipId = id || generatedId;
  const [open, setOpen] = useState(false);

  return (
    <span
      className="s3-tooltip"
      data-placement={placement}
      onBlur={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onKeyDown={(event) => event.key === 'Escape' && setOpen(false)}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      {React.isValidElement(children) ? React.cloneElement(children, { 'aria-describedby': open ? tooltipId : undefined }) : children}
      <span className={classNames('s3-tooltip__content', open && 's3-tooltip__content-open')} id={tooltipId} role="tooltip">
        {content}
      </span>
    </span>
  );
}

export function S3Popover({ children, className, content, id, onOpenChange, open: controlledOpen, placement = 'bottom-start' }) {
  const generatedId = useId();
  const popoverId = id || generatedId;
  const [uncontrolledOpen, setUncontrolledOpen] = useState(false);
  const open = controlledOpen ?? uncontrolledOpen;
  const rootRef = useRef(null);
  const setOpen = (nextOpen, event) => {
    setUncontrolledOpen(nextOpen);
    onOpenChange?.(nextOpen, event);
  };

  useEffect(() => {
    if (!open) return undefined;
    const handlePointerDown = (event) => {
      // outside click closes the popover without taking ownership of product actions.
      if (!rootRef.current?.contains(event.target)) setOpen(false, event);
    };
    const handleKeyDown = (event) => event.key === 'Escape' && setOpen(false, event);
    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [open]);

  const trigger = React.isValidElement(children)
    ? React.cloneElement(children, {
        'aria-controls': open ? popoverId : undefined,
        'aria-expanded': open,
        'aria-haspopup': 'dialog',
        onClick: (event) => {
          children.props.onClick?.(event);
          setOpen(!open, event);
        },
      })
    : children;

  return (
    <span className={classNames('s3-popover', className)} data-placement={placement} ref={rootRef}>
      {trigger}
      {open ? (
        <div className="s3-popover__content" id={popoverId} role="dialog" tabIndex={-1}>
          {content}
        </div>
      ) : null}
    </span>
  );
}

export function S3Banner({ actions, children, className, description, dismissLabel = 'Dismiss', icon, onDismiss, title, tone = 'info' }) {
  const Icon = icon || toneIcons[tone] || Info;
  const live = tone === 'danger' || tone === 'error' ? 'assertive' : 'polite';
  return (
    <section className={classNames('s3-banner', `s3-banner-${tone}`, className)} role="status" aria-live={live}>
      <Icon className="s3-banner__icon" aria-hidden="true" />
      <div className="s3-banner__content">
        {title ? <p className="s3-banner__title">{title}</p> : null}
        {description ? <p className="s3-banner__description">{description}</p> : null}
        {children}
      </div>
      {actions ? <div className="s3-banner__actions">{actions}</div> : null}
      {onDismiss ? <S3IconButton ariaLabel={dismissLabel} icon={X} onClick={onDismiss} size="sm" variant="ghost" /> : null}
    </section>
  );
}

export function S3Toast({ action, children, className, description, dismissLabel = 'Dismiss', duration = 'default', onDismiss, title, tone = 'info' }) {
  const [paused, setPaused] = useState(false);
  const timeout = typeof duration === 'number' ? duration : toastDurations[duration];

  useEffect(() => {
    if (!onDismiss || paused || !timeout) return undefined;
    const timer = window.setTimeout(onDismiss, timeout);
    return () => window.clearTimeout(timer);
  }, [onDismiss, paused, timeout]);

  const Icon = toneIcons[tone] || Info;
  return (
    <div
      className={classNames('s3-toast', `s3-toast-${tone}`, className)}
      onBlur={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      role={tone === 'danger' || tone === 'error' ? 'alert' : 'status'}
      aria-live={tone === 'danger' || tone === 'error' ? 'assertive' : 'polite'}
    >
      <Icon className="s3-toast__icon" aria-hidden="true" />
      <div className="s3-toast__content">
        {title ? <p className="s3-toast__title">{title}</p> : null}
        {description ? <p className="s3-toast__description">{description}</p> : null}
        {children}
      </div>
      {action}
      {onDismiss ? <S3IconButton ariaLabel={dismissLabel} icon={X} onClick={onDismiss} size="sm" variant="ghost" /> : null}
    </div>
  );
}

export function S3ToastViewport({ children, className, placement = 'bottom-end' }) {
  return <div className={classNames('s3-toast-viewport', className)} data-placement={placement}>{children}</div>;
}

export function S3ToastAction({ children, onClick }) {
  return <S3Button size="sm" type="button" variant="secondary" onClick={onClick}>{children}</S3Button>;
}

export function S3ToastProvider({ children }) {
  return children;
}

export function S3OperationFeedback({
  className,
  errorContent,
  loadingContent,
  status = 'idle',
  successContent,
}) {
  const content = useMemo(() => {
    if (status === 'loading') return loadingContent;
    if (status === 'success') return successContent;
    if (status === 'error') return errorContent;
    return null;
  }, [errorContent, loadingContent, status, successContent]);

  if (!content) return null;
  const Icon = status === 'loading' ? Loader2 : toneIcons[status] || Info;
  return (
    <div className={classNames('s3-operation-feedback', `s3-operation-feedback-${status}`, className)} role="status" aria-live={status === 'error' ? 'assertive' : 'polite'}>
      <Icon className="s3-operation-feedback__icon" aria-hidden="true" />
      <div>{content}</div>
    </div>
  );
}
