import React from 'react';
import { classNames } from '../utilities/classNames.js';

const TONE_CLASS = {
  accent: 'accent',
  caution: 'warning',
  danger: 'danger',
  error: 'danger',
  info: 'info',
  neutral: 'neutral',
  success: 'success',
  warning: 'warning',
};

export function S3StatusBadge({ children, className, icon: Icon, status, tone = status || 'neutral' }) {
  const normalizedTone = TONE_CLASS[tone] || 'neutral';

  return (
    <span className={classNames('s3-badge', `s3-badge-${normalizedTone}`, className)}>
      {Icon ? <Icon className="s3-badge__icon" aria-hidden="true" /> : null}
      {children}
    </span>
  );
}
