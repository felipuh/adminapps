import React from 'react';
import { Inbox } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';

export function S3EmptyState({
  action,
  className,
  colSpan,
  description,
  icon,
  title,
  message,
}) {
  const Icon = icon || Inbox;
  const resolvedTitle = title || message;

  const content = (
    <div className={classNames('s3-empty-state', className)}>
      <span className="s3-state-icon s3-state-icon-neutral">
        <Icon className="s3-state-icon__svg" aria-hidden="true" />
      </span>
      {resolvedTitle ? <p className="s3-state-title">{resolvedTitle}</p> : null}
      {description ? <p className="s3-state-description">{description}</p> : null}
      {action ? <div className="s3-state-action">{action}</div> : null}
    </div>
  );

  if (colSpan) {
    return (
      <tr>
        <td colSpan={colSpan}>{content}</td>
      </tr>
    );
  }

  return content;
}
