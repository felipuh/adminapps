import React from 'react';
import { Loader2 } from 'lucide-react';
import { classNames } from '../utilities/classNames.js';

const VARIANT_CLASS = {
  ghost: 's3-button-ghost',
  primary: 's3-button-primary',
  secondary: 's3-button-secondary',
  danger: 's3-button-danger',
  success: 's3-button-success',
};

const SIZE_CLASS = {
  sm: 's3-button-sm',
  md: 's3-button-md',
  lg: 's3-button-lg',
};

export const S3Button = React.forwardRef(function S3Button({
  as: Component = 'button',
  children,
  className,
  disabled = false,
  endIcon: EndIcon,
  icon: StartIcon,
  loading = false,
  size = 'md',
  startIcon,
  type = 'button',
  variant = 'primary',
  ...props
}, ref) {
  const isButton = Component === 'button';
  const Icon = StartIcon || startIcon;

  if (!children) {
    throw new Error('S3Button requires visible children. Use S3IconButton for icon-only actions.');
  }

  return (
    <Component
      ref={ref}
      className={classNames('s3-button', VARIANT_CLASS[variant], SIZE_CLASS[size], className)}
      disabled={isButton ? disabled || loading : undefined}
      aria-disabled={!isButton && (disabled || loading) ? 'true' : undefined}
      aria-busy={loading ? 'true' : undefined}
      type={isButton ? type : undefined}
      {...props}
    >
      {loading ? <Loader2 className="s3-button__spinner" aria-hidden="true" /> : null}
      {!loading && Icon ? <Icon className="s3-button__icon" aria-hidden="true" /> : null}
      <span className="s3-button__content">{children}</span>
      {EndIcon ? <EndIcon className="s3-button__icon" aria-hidden="true" /> : null}
    </Component>
  );
});

export const S3IconButton = React.forwardRef(function S3IconButton({
  as: Component = 'button',
  ariaLabel,
  className,
  disabled = false,
  icon: Icon,
  loading = false,
  size = 'md',
  type = 'button',
  variant = 'secondary',
  ...props
}, ref) {
  const isButton = Component === 'button';

  if (!ariaLabel && !props['aria-label']) {
    throw new Error('S3IconButton requires ariaLabel or aria-label.');
  }

  if (!Icon && !loading) {
    throw new Error('S3IconButton requires an icon.');
  }

  return (
    <Component
      ref={ref}
      className={classNames('s3-button', 's3-icon-button', VARIANT_CLASS[variant], SIZE_CLASS[size], className)}
      disabled={isButton ? disabled || loading : undefined}
      aria-disabled={!isButton && (disabled || loading) ? 'true' : undefined}
      aria-label={ariaLabel || props['aria-label']}
      aria-busy={loading ? 'true' : undefined}
      type={isButton ? type : undefined}
      {...props}
    >
      {loading ? <Loader2 className="s3-button__spinner" aria-hidden="true" /> : <Icon className="s3-button__icon" aria-hidden="true" />}
    </Component>
  );
});
